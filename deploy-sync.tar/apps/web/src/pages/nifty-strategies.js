import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { restoreUserSession } from '../lib/auth-client';
import { useTheme } from '../lib/ThemePicker';
import { applyTheme } from '../lib/themes';

const FORMULA_BLEND_WEIGHTS = {
  blackScholes: 0.35,
  binomialCrr: 0.35,
  bachelier: 0.15,
  monteCarlo: 0.15,
};

const WHAT_IF_STEP = 50;
const WHAT_IF_STEPS_EACH_SIDE = 10;
const LEG_QUANTITY_OPTIONS = Array.from({ length: 10 }, (_, index) => String(index + 1));
const TRANSACTION_COST_PER_ORDER = 30;
const CURRENT_VALUATION_OPTIONS = ['live', 'blend', 'blackScholes', 'binomialCrr', 'bachelier', 'monteCarlo', 'intrinsic'];
const REFRESH_INTERVAL_OPTIONS = [
  { value: 0, label: 'Manual only' },
  { value: 15, label: '15 sec' },
  { value: 30, label: '30 sec' },
  { value: 60, label: '1 min' },
  { value: 120, label: '2 min' },
  { value: 300, label: '5 min' },
];
const MARKET_SESSION_OPTIONS = [
  { value: 'always', label: 'Always on', timezone: 'UTC', days: [0, 1, 2, 3, 4, 5, 6], start: '00:00', end: '23:59' },
  { value: 'nse', label: 'India NSE: 9:00-15:30 IST', timezone: 'Asia/Kolkata', days: [1, 2, 3, 4, 5], start: '09:00', end: '15:30' },
  { value: 'us', label: 'US Equities: 9:30-16:00 ET', timezone: 'America/New_York', days: [1, 2, 3, 4, 5], start: '09:30', end: '16:00' },
  { value: 'europe', label: 'Europe: 8:00-16:30 London', timezone: 'Europe/London', days: [1, 2, 3, 4, 5], start: '08:00', end: '16:30' },
  { value: 'crypto', label: 'Crypto: 24x7', timezone: 'UTC', days: [0, 1, 2, 3, 4, 5, 6], start: '00:00', end: '23:59' },
];

const EmbeddedOptionsStrategyPage = dynamic(
  () => import('./options-strategy').then((mod) => mod.OptionsStrategyPage),
  {
    ssr: false,
    loading: () => (
      <div style={{ padding: '18px', borderRadius: '14px', border: '1px solid #1e293b', background: 'rgba(15, 23, 42, 0.82)', color: '#94a3b8' }}>
        Loading strategy builder...
      </div>
    ),
  },
);

function parseTimeParts(value) {
  const [hoursText, minutesText] = String(value || '00:00').split(':');
  const hours = Number(hoursText);
  const minutes = Number(minutesText);
  return {
    hours: Number.isFinite(hours) ? hours : 0,
    minutes: Number.isFinite(minutes) ? minutes : 0,
  };
}

function getZonedTimeParts(date, timezone) {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: timezone,
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  const parts = formatter.formatToParts(date);
  const lookup = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  const weekdayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return {
    day: weekdayMap[lookup.weekday] ?? 0,
    hour: Number(lookup.hour || 0),
    minute: Number(lookup.minute || 0),
  };
}

function isWithinMarketSession(sessionKey, now = new Date()) {
  const session = MARKET_SESSION_OPTIONS.find((entry) => entry.value === sessionKey) || MARKET_SESSION_OPTIONS[0];
  if (session.value === 'always' || session.value === 'crypto') return true;
  const zoned = getZonedTimeParts(now, session.timezone);
  if (!session.days.includes(zoned.day)) return false;
  const start = parseTimeParts(session.start);
  const end = parseTimeParts(session.end);
  const currentMinutes = (zoned.hour * 60) + zoned.minute;
  const startMinutes = (start.hours * 60) + start.minutes;
  const endMinutes = (end.hours * 60) + end.minutes;
  return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
}

function getRefreshPauseReason({ autoRefreshEnabled, refreshIntervalSeconds, refreshSession, pageVisible }) {
  if (!autoRefreshEnabled || refreshIntervalSeconds <= 0) return 'Manual refresh only';
  if (!pageVisible) return 'Paused while this tab is hidden';
  if (!isWithinMarketSession(refreshSession)) {
    const session = MARKET_SESSION_OPTIONS.find((entry) => entry.value === refreshSession);
    return `Paused outside ${session?.label || 'selected market'} hours`;
  }
  return null;
}

function normalizePremium(value) {
  return Number((Number(value) || 0).toFixed(2));
}

function formatExpiryDisplay(unixSeconds) {
  const expiry = Number(unixSeconds);
  if (!Number.isFinite(expiry) || expiry <= 0) return 'No expiry';
  const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000;
  const ms = expiry * 1000 + IST_OFFSET_MS;
  const date = new Date(ms);
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${days[date.getUTCDay()]} ${date.getUTCDate()} ${months[date.getUTCMonth()]}`;
}

function resolveLegExpiry(leg, strategy = null) {
  const fromLeg = Number(leg?.expiry);
  if (Number.isFinite(fromLeg) && fromLeg > 0) return fromLeg;
  const fromStrategy = Number(strategy?.selectedExpiry);
  if (Number.isFinite(fromStrategy) && fromStrategy > 0) return fromStrategy;
  return null;
}

function getStrategyExpiries(strategy = null) {
  const expiries = new Set();
  (strategy?.legs || []).forEach((leg) => {
    const expiry = resolveLegExpiry(leg, strategy);
    if (expiry) expiries.add(expiry);
  });
  if (!expiries.size) {
    const selected = Number(strategy?.selectedExpiry);
    if (Number.isFinite(selected) && selected > 0) expiries.add(selected);
  }
  return Array.from(expiries).sort((left, right) => left - right);
}

function getLegEditorExpiryOptions(strategy = null) {
  const optionSet = new Set(getStrategyExpiries(strategy));
  (strategy?.availableExpiries || []).forEach((expiry) => {
    const numeric = Number(expiry);
    if (Number.isFinite(numeric) && numeric > 0) optionSet.add(numeric);
  });
  const selected = Number(strategy?.selectedExpiry);
  if (Number.isFinite(selected) && selected > 0) optionSet.add(selected);
  return Array.from(optionSet).sort((left, right) => left - right);
}

function getExpiryBadgeTone(unixSeconds) {
  const expiry = Number(unixSeconds);
  if (!Number.isFinite(expiry) || expiry <= 0) {
    return { background: '#33415533', color: '#cbd5e1', border: '#47556966' };
  }
  const daysLeft = (expiry * 1000 - Date.now()) / (24 * 60 * 60 * 1000);
  if (daysLeft <= 7) {
    return { background: '#f59e0b22', color: '#fbbf24', border: '#f59e0b66' };
  }
  return { background: '#3b82f622', color: '#93c5fd', border: '#3b82f666' };
}

function resolveChainPremium(chainMap = { CE: {}, PE: {} }, leg = {}) {
  const optionType = leg.optionType;
  const strike = Number(leg.strike);
  const expiry = Number(leg.expiry);
  if (!optionType || !Number.isFinite(strike) || !Number.isFinite(expiry) || expiry <= 0) return null;
  // Only use the exact expiry, never fallback
  const byExpiry = chainMap?.byExpiry || {};
  if (byExpiry[expiry] && byExpiry[expiry][optionType] && byExpiry[expiry][optionType][strike] != null) {
    return byExpiry[expiry][optionType][strike];
  }
  // If not found, do NOT fallback to any other expiry
  return null;
}

function getPricingSourceLabel(value = 'blend') {
  const labels = {
    blend: 'Formula Blend',
    blackScholes: 'Black-Scholes',
    binomialCrr: 'Binomial CRR',
    bachelier: 'Bachelier',
    monteCarlo: 'Monte Carlo GBM',
    intrinsic: 'Intrinsic Only',
    live: 'Live / Chain',
  };
  return labels[value] || 'Formula Blend';
}

function resolveExpectedOptionPrice(contract, pricingSource = 'blend') {
  const formulaMap = Object.fromEntries((contract?.formulaResults || []).map((entry) => [entry.key, Number(entry.price)]));

  if (pricingSource === 'live') {
    return normalizePremium(contract?.livePremium ?? formulaMap.blackScholes ?? formulaMap.intrinsic ?? 0);
  }

  if (pricingSource !== 'blend') {
    return normalizePremium(formulaMap[pricingSource] ?? contract?.livePremium ?? formulaMap.blackScholes ?? formulaMap.intrinsic ?? 0);
  }

  const weightedEntries = Object.entries(FORMULA_BLEND_WEIGHTS)
    .map(([key, weight]) => ({ value: Number(formulaMap[key]), weight }))
    .filter((entry) => Number.isFinite(entry.value));

  if (weightedEntries.length) {
    const weightedTotal = weightedEntries.reduce((sum, entry) => sum + (entry.value * entry.weight), 0);
    const totalWeight = weightedEntries.reduce((sum, entry) => sum + entry.weight, 0) || 1;
    return normalizePremium(weightedTotal / totalWeight);
  }

  return normalizePremium(contract?.livePremium ?? formulaMap.blackScholes ?? formulaMap.intrinsic ?? 0);
}

function buildExpectedPricingUrl(strategy, expiriesOverride = null) {
  const expiries = Array.from(new Set((expiriesOverride || getStrategyExpiries(strategy) || []).map((expiry) => Number(expiry)).filter((expiry) => Number.isFinite(expiry) && expiry > 0))).sort((left, right) => left - right);
  const params = new URLSearchParams({
    symbol: 'NIFTY',
    strikeGap: '50',
    strikeLevels: '40',
    expiryCount: String(Math.max(1, expiries.length || 1)),
  });
  if (expiries.length) params.set('expiries', expiries.join(','));
  if (strategy?.rateInput) params.set('rate', String(strategy.rateInput));
  if (strategy?.ivInput) params.set('iv', String(strategy.ivInput));
  return `/api/options-expected-price?${params.toString()}`;
}

function buildExpiryUniverseUrl(strategy = null) {
  const params = new URLSearchParams({ symbol: 'NIFTY' });
  return `/api/options-chain?${params.toString()}`;
}

function buildWhatIfBaseSpot(spot) {
  const numericSpot = Number(spot) || 0;
  return Math.max(0, Number(numericSpot.toFixed(2)));
}

function buildWhatIfAxisSpot(spot) {
  const numericSpot = Number(spot) || 0;
  return Math.max(0, Math.round(numericSpot / WHAT_IF_STEP) * WHAT_IF_STEP);
}

function buildWhatIfSpots(spot) {
  const currentSpot = buildWhatIfBaseSpot(spot);
  const axisSpot = buildWhatIfAxisSpot(currentSpot);
  const steppedSpots = Array.from({ length: (WHAT_IF_STEPS_EACH_SIDE * 2) + 1 }, (_, index) => {
    const offset = (index - WHAT_IF_STEPS_EACH_SIDE) * WHAT_IF_STEP;
    return Math.max(0, axisSpot + offset);
  });

  return [...new Set([...steppedSpots, currentSpot].map((value) => Number(value.toFixed(2))))]
    .sort((left, right) => left - right);
}

function buildWhatIfPricingUrl(strategy, referenceSpot) {
  const expiries = getStrategyExpiries(strategy);
  const params = new URLSearchParams({
    symbol: 'NIFTY',
    strikeGap: '50',
    strikeLevels: '1',
    expiryCount: String(Math.max(1, expiries.length || 1)),
    spot: String(Number(referenceSpot || 0).toFixed(2)),
    scenarioSpots: buildWhatIfSpots(referenceSpot).join(','),
    strikes: [...new Set((strategy?.legs || []).map((leg) => Number(leg.strike)).filter((strike) => Number.isFinite(strike) && strike > 0))].join(','),
  });
  if (expiries.length) params.set('expiries', expiries.join(','));
  if (strategy?.rateInput) params.set('rate', String(strategy.rateInput));
  if (strategy?.ivInput) params.set('iv', String(strategy.ivInput));
  return `/api/options-expected-price?${params.toString()}`;
}

function buildLegCatalog(chainMap = { CE: {}, PE: {} }, currentSpot = 0, legs = []) {
  const spot = buildWhatIfBaseSpot(currentSpot || 0);
  const strikeFloor = Math.max(0, Math.floor((spot - 1500) / 50) * 50);
  const strikeCeil = Math.max(0, Math.ceil((spot + 1500) / 50) * 50);
  const windowStrikes = [];
  for (let strike = strikeFloor; strike <= strikeCeil; strike += 50) {
    windowStrikes.push(strike);
  }
  return ['CE', 'PE'].reduce((catalog, optionType) => {
    const byExpiry = chainMap?.byExpiry || {};
    let entries = [];
    Object.keys(byExpiry).forEach((expiryKey) => {
      const expiry = Number(expiryKey);
      if (!Number.isFinite(expiry) || expiry <= 0) return;
      const expiryEntries = Object.entries(byExpiry?.[expiry]?.[optionType] || {})
        .map(([strike, premium]) => ({ strike: Number(strike), premium: Number(premium), expiry }));
      entries = entries.concat(expiryEntries);
    });
    const expirySet = new Set(entries.map((entry) => entry.expiry));
    expirySet.forEach((expiry) => {
      windowStrikes.forEach((strike) => {
        if (entries.some((entry) => entry.expiry === expiry && entry.strike === strike)) return;
        const premium = byExpiry?.[expiry]?.[optionType]?.[strike] ?? null;
        entries.push({ strike, premium: premium != null ? Number(premium) : null, expiry });
      });
    });
    catalog[optionType] = entries.sort((left, right) => left.strike - right.strike);
    return catalog;
  }, { CE: [], PE: [] });
}

function getLegCatalogOptions(strategy, optionType = 'CE') {
  return strategy?.legCatalog?.[optionType] || [];
}

function getLegCatalogOption(strategy, optionType = 'CE', strike, expiry) {
  return getLegCatalogOptions(strategy, optionType).find((entry) => String(entry.strike) === String(strike) && (expiry == null || String(entry.expiry) === String(expiry))) || null;
}

function buildLegEditorDraft(strategy, leg = null) {
  const optionType = leg?.optionType || 'CE';
  const options = getLegCatalogOptions(strategy, optionType);
  const fallbackOption = options[0] || null;
  const expiryOptions = getLegEditorExpiryOptions(strategy);
  const fallbackExpiry = Number(leg?.expiry) || Number(strategy?.selectedExpiry) || expiryOptions[0] || '';
  const strike = leg?.strike ?? fallbackOption?.strike ?? '';
  const selectedOption = getLegCatalogOption(strategy, optionType, strike, fallbackExpiry) || null;
  const directPremium = resolveChainPremium(strategy?.liveChainMap || { CE: {}, PE: {}, byExpiry: {} }, {
    optionType,
    strike,
    expiry: fallbackExpiry,
  });
  // Only use directPremium if expiry matches, else do not fallback to any other premium
  const marketPremium = directPremium != null ? directPremium : (selectedOption?.premium ?? '');
  const entryPremium = Number(leg?.premium ?? marketPremium ?? 0);

  return {
    strategyId: strategy.id,
    legId: leg?.id ?? null,
    side: leg?.side || 'SELL',
    optionType,
    expiry: fallbackExpiry ? String(fallbackExpiry) : '',
    strike: strike ? String(strike) : '',
    premium: entryPremium ? String(normalizePremium(entryPremium).toFixed(2)) : '',
    marketPremium: marketPremium ? String(normalizePremium(marketPremium).toFixed(2)) : '',
    quantity: String(Math.max(1, parseInt(leg?.quantity || 1, 10) || 1)),
  };
}

function calculateTransactionCost(transactions = []) {
  return (transactions || []).length * TRANSACTION_COST_PER_ORDER;
}

function optionIntrinsic(optionType, strike, spot) {
  if (optionType === 'CE') return Math.max(spot - strike, 0);
  return Math.max(strike - spot, 0);
}

function legPayoffAtExpiry(leg, spot) {
  const quantity = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
  const intrinsic = optionIntrinsic(leg.optionType, Number(leg.strike), spot);
  const entryPremium = Number(leg.premium) || 0;
  const premiumEffect = leg.side === 'SELL' ? entryPremium : -entryPremium;
  const intrinsicEffect = leg.side === 'SELL' ? -intrinsic : intrinsic;
  return (premiumEffect + intrinsicEffect) * quantity;
}

function syncLegsWithChain(legs = [], chainMap = { CE: {}, PE: {} }) {
  return legs.map((leg) => {
    const latest = resolveChainPremium(chainMap, leg);
    return {
      ...leg,
      quantity: Math.max(1, parseInt(leg.quantity || 1, 10) || 1),
      // Only use marketPremium if exact expiry match, else leave blank
      marketPremium: latest == null ? '' : normalizePremium(latest),
    };
  });
}

function computeProjectedScenarioValues(legs = [], lotSize = 1, scenarioContracts = [], pricingSource = 'blend', baseSpot = 0) {
  return scenarioContracts.map((scenario) => {
    const contractLookup = new Map(
      (scenario.contracts || []).map((contract) => [`${Number(contract.expiryUnix) || 0}:${contract.type}:${Number(contract.strike)}`, resolveExpectedOptionPrice(contract, pricingSource)]),
    );

    const projectedCloseValue = legs.reduce((sum, leg) => {
      const quantity = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
      const expiryKey = Number(leg.expiry) || 0;
      const projectedPremium = contractLookup.get(`${expiryKey}:${leg.optionType}:${Number(leg.strike)}`) ?? normalizePremium(leg.marketPremium ?? leg.premium);
      return sum + ((leg.side === 'BUY' ? projectedPremium : -projectedPremium) * quantity);
    }, 0) * lotSize;

    const projectedMtm = legs.reduce((sum, leg) => {
      const quantity = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
      const entryPremium = Number(leg.premium) || 0;
      const expiryKey = Number(leg.expiry) || 0;
      const projectedPremium = contractLookup.get(`${expiryKey}:${leg.optionType}:${Number(leg.strike)}`) ?? normalizePremium(leg.marketPremium ?? leg.premium);
      return sum + ((leg.side === 'SELL' ? entryPremium - projectedPremium : projectedPremium - entryPremium) * quantity);
    }, 0) * lotSize;

    return {
      spot: Number(Number(scenario.spot || 0).toFixed(2)),
      offset: Number((Number(scenario.spot || 0) - Number(baseSpot || 0)).toFixed(2)),
      value: Number(projectedMtm.toFixed(2)),
      closeValue: Number(projectedCloseValue.toFixed(2)),
      isCurrent: Math.abs(Number(scenario.spot || 0) - Number(baseSpot || 0)) < 0.01,
    };
  });
}

function computeStrategyMetrics(legs = [], lotSize = 1, spotPrice = 0) {
  if (!legs.length) {
    return {
      points: [],
      scenarios: [],
      maxProfit: 0,
      maxLoss: 0,
      currentPayoff: 0,
      entryNetPremium: 0,
      liveCloseValue: 0,
      premiumRemaining: 0,
      capturedPremium: 0,
      markToMarket: 0,
      breakEvens: [],
      profitRange: 'None',
      lossRange: 'None',
      minY: 0,
      maxY: 0,
    };
  }

  const sortedStrikes = [...new Set(legs.map((leg) => Number(leg.strike) || 0))].sort((left, right) => left - right);
  const lower = sortedStrikes[0] || Math.max(spotPrice - 2000, 0);
  const upper = sortedStrikes[sortedStrikes.length - 1] || (spotPrice + 2000);
  const start = Math.max(Math.min(lower - 2000, spotPrice - 2200), 0);
  const end = Math.max(upper + 2000, spotPrice + 2200);
  const step = Math.max(Math.round((end - start) / 40), 50);

  const points = [];
  for (let spot = start; spot <= end; spot += step) {
    const perUnitPayoff = legs.reduce((sum, leg) => sum + legPayoffAtExpiry(leg, spot), 0);
    points.push({ spot, value: Number((perUnitPayoff * lotSize).toFixed(2)) });
  }

  const values = points.map((point) => point.value);
  const maxProfit = Math.max(...values);
  const maxLoss = Math.min(...values);
  const currentPayoff = legs.reduce((sum, leg) => sum + legPayoffAtExpiry(leg, spotPrice), 0) * lotSize;
  const entryNetPremium = legs.reduce((sum, leg) => {
    const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
    return sum + ((leg.side === 'SELL' ? Number(leg.premium) || 0 : -(Number(leg.premium) || 0)) * qty);
  }, 0) * lotSize;
  const liveCloseValue = legs.reduce((sum, leg) => {
    const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
    const marketPremium = Number(leg.marketPremium ?? leg.premium) || 0;
    return sum + ((leg.side === 'BUY' ? marketPremium : -marketPremium) * qty);
  }, 0) * lotSize;
  const premiumRemaining = legs.reduce((sum, leg) => {
    const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
    const marketPremium = Number(leg.marketPremium ?? leg.premium) || 0;
    return sum + ((leg.side === 'SELL' ? marketPremium : 0) * qty);
  }, 0) * lotSize;
  const premiumSoldAtEntry = legs.reduce((sum, leg) => {
    const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
    return sum + ((leg.side === 'SELL' ? Number(leg.premium) || 0 : 0) * qty);
  }, 0) * lotSize;
  const capturedPremium = premiumSoldAtEntry - premiumRemaining;
  const markToMarket = legs.reduce((sum, leg) => {
    const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
    const marketPremium = Number(leg.marketPremium ?? leg.premium) || 0;
    const entryPremium = Number(leg.premium) || 0;
    return sum + ((leg.side === 'SELL' ? entryPremium - marketPremium : marketPremium - entryPremium) * qty);
  }, 0) * lotSize;

  const breakEvens = [];
  for (let index = 1; index < points.length; index += 1) {
    const prev = points[index - 1];
    const cur = points[index];
    if ((prev.value <= 0 && cur.value >= 0) || (prev.value >= 0 && cur.value <= 0)) {
      const ratio = Math.abs(prev.value) / (Math.abs(prev.value) + Math.abs(cur.value));
      breakEvens.push(Math.round(prev.spot + ratio * (cur.spot - prev.spot)));
    }
  }

  const profitZones = [];
  const lossZones = [];
  let zoneStart = null;
  let zoneType = null;
  for (let index = 0; index < points.length; index += 1) {
    const point = points[index];
    const currentType = point.value >= 0 ? 'profit' : 'loss';
    if (zoneType === null) {
      zoneStart = point.spot;
      zoneType = currentType;
    } else if (currentType !== zoneType) {
      const prev = points[index - 1];
      const ratio = Math.abs(prev.value) / (Math.abs(prev.value) + Math.abs(point.value));
      const boundary = Math.round(prev.spot + ratio * (point.spot - prev.spot));
      const zone = { from: zoneStart, to: boundary };
      if (zoneType === 'profit') profitZones.push(zone);
      else lossZones.push(zone);
      zoneStart = boundary;
      zoneType = currentType;
    }
  }
  if (zoneType && points.length) {
    const zone = { from: zoneStart, to: points[points.length - 1].spot };
    if (zoneType === 'profit') profitZones.push(zone);
    else lossZones.push(zone);
  }

  const scenarioOffsets = [-2000, -1000, -500, 0, 500, 1000, 2000];
  const scenarios = scenarioOffsets.map((offset) => {
    const spot = Math.max(0, Math.round((spotPrice || 0) + offset));
    const pnl = legs.reduce((sum, leg) => sum + legPayoffAtExpiry(leg, spot), 0) * lotSize;
    return { offset, spot, value: Number(pnl.toFixed(2)) };
  });

  return {
    points,
    scenarios,
    maxProfit,
    maxLoss,
    currentPayoff: Number(currentPayoff.toFixed(2)),
    entryNetPremium: Number(entryNetPremium.toFixed(2)),
    liveCloseValue: Number(liveCloseValue.toFixed(2)),
    premiumRemaining: Number(premiumRemaining.toFixed(2)),
    capturedPremium: Number(capturedPremium.toFixed(2)),
    markToMarket: Number(markToMarket.toFixed(2)),
    breakEvens,
    profitRange: profitZones.length ? profitZones.map((zone) => `${zone.from}–${zone.to}`).join(', ') : 'None',
    lossRange: lossZones.length ? lossZones.map((zone) => `${zone.from}–${zone.to}`).join(', ') : 'None',
    minY: Math.min(...values),
    maxY: Math.max(...values),
  };
}

function formatCurrency(value) {
  return `Rs. ${Number(value || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function getTickerAppearance(key, theme) {
  const palette = {
    NIFTY50: {
      border: '#0f766e',
      background: 'linear-gradient(135deg, rgba(15,118,110,0.10), rgba(15,23,42,0.94))',
      glow: 'rgba(45,212,191,0.08)',
      accent: '#dffcf6',
      price: '#f8fafc',
    },
    BANKNIFTY: {
      border: '#1d4ed8',
      background: 'linear-gradient(135deg, rgba(29,78,216,0.10), rgba(15,23,42,0.94))',
      glow: 'rgba(96,165,250,0.08)',
      accent: '#e5f0ff',
      price: '#f8fafc',
    },
    SENSEX: {
      border: '#7c3aed',
      background: 'linear-gradient(135deg, rgba(124,58,237,0.10), rgba(15,23,42,0.94))',
      glow: 'rgba(167,139,250,0.08)',
      accent: '#f0eaff',
      price: '#f8fafc',
    },
    INDIAVIX: {
      border: '#ea580c',
      background: 'linear-gradient(135deg, rgba(234,88,12,0.12), rgba(15,23,42,0.94))',
      glow: 'rgba(251,146,60,0.08)',
      accent: '#fff1de',
      price: '#f8fafc',
    },
    DOWFUT: {
      border: '#be123c',
      background: 'linear-gradient(135deg, rgba(190,18,60,0.2), rgba(69,10,10,0.88))',
      glow: 'rgba(251,113,133,0.18)',
      accent: '#fda4af',
      price: '#fff1f2',
    },
    SP500FUT: {
      border: '#2563eb',
      background: 'linear-gradient(135deg, rgba(37,99,235,0.18), rgba(15,23,42,0.9))',
      glow: 'rgba(96,165,250,0.18)',
      accent: '#bfdbfe',
      price: '#eff6ff',
    },
    HANGSENG: {
      border: '#059669',
      background: 'linear-gradient(135deg, rgba(5,150,105,0.2), rgba(6,44,37,0.9))',
      glow: 'rgba(52,211,153,0.18)',
      accent: '#86efac',
      price: '#ecfdf5',
    },
    NIKKEI: {
      border: '#d97706',
      background: 'linear-gradient(135deg, rgba(217,119,6,0.2), rgba(69,26,3,0.9))',
      glow: 'rgba(251,191,36,0.18)',
      accent: '#fde68a',
      price: '#fffbeb',
    },
    DAX: {
      border: '#0891b2',
      background: 'linear-gradient(135deg, rgba(8,145,178,0.2), rgba(8,47,73,0.9))',
      glow: 'rgba(103,232,249,0.18)',
      accent: '#a5f3fc',
      price: '#ecfeff',
    },
    FTSE: {
      border: '#65a30d',
      background: 'linear-gradient(135deg, rgba(101,163,13,0.22), rgba(26,46,5,0.92))',
      glow: 'rgba(190,242,100,0.18)',
      accent: '#d9f99d',
      price: '#f7fee7',
    },
    CRUDEWTI: {
      border: '#b45309',
      background: 'linear-gradient(135deg, rgba(180,83,9,0.24), rgba(41,20,7,0.9))',
      glow: 'rgba(251,146,60,0.2)',
      accent: '#fdba74',
      price: '#fff7ed',
    },
    CRUDEBRENT: {
      border: '#9a3412',
      background: 'linear-gradient(135deg, rgba(154,52,18,0.24), rgba(60,20,10,0.9))',
      glow: 'rgba(253,186,116,0.2)',
      accent: '#fed7aa',
      price: '#ffedd5',
    },
  };

  return palette[key] || {
    border: theme.cardBorder,
    background: 'linear-gradient(135deg, rgba(51,65,85,0.12), rgba(15,23,42,0.94))',
    glow: 'rgba(148,163,184,0.08)',
    accent: '#f1f5f9',
    price: '#f8fafc',
  };
}

function TinyTrendSparkline({ history = [], color, styles }) {
  const values = (history || []).filter((value) => Number.isFinite(Number(value))).map((value) => Number(value));
  if (values.length < 2) {
    return <div style={styles.tickerSparklineEmpty}>No 1D trend</div>;
  }

  const width = 148;
  const height = 42;
  const padding = 3;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const points = values.map((value, index) => {
    const x = padding + ((index / (values.length - 1)) * (width - (padding * 2)));
    const y = height - padding - (((value - min) / range) * (height - (padding * 2)));
    return `${x},${y}`;
  }).join(' ');
  const areaPoints = `${padding},${height - padding} ${points} ${width - padding},${height - padding}`;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="none"
      style={styles.tickerSparkline}
      aria-label="1 day price trend"
    >
      <polyline
        fill="none"
        stroke="rgba(255,255,255,0.12)"
        strokeWidth="1"
        points={`${padding},${height / 2} ${width - padding},${height / 2}`}
      />
      <polyline
        fill="none"
        stroke="rgba(255,255,255,0.08)"
        strokeWidth="1"
        points={`${padding},${height - padding} ${width - padding},${height - padding}`}
      />
      <polygon fill={`${color}20`} points={areaPoints} />
      <polyline fill="none" stroke="rgba(255,255,255,0.14)" strokeWidth="4" strokeLinejoin="round" strokeLinecap="round" points={points} />
      <polyline fill="none" stroke={color} strokeWidth="2.3" strokeLinejoin="round" strokeLinecap="round" points={points} />
      <circle cx={width - padding} cy={Number(points.split(' ').slice(-1)[0].split(',')[1])} r="3.2" fill={color} stroke="rgba(255,255,255,0.92)" strokeWidth="1.2" />
    </svg>
  );
}

function OrbitalLoader({ label = 'Loading saved strategies...' }) {
  return (
    <div style={{
      borderRadius: '18px',
      border: '1px solid rgba(56, 189, 248, 0.28)',
      padding: '24px 16px',
      display: 'grid',
      justifyItems: 'center',
      gap: '12px',
      background: 'radial-gradient(circle at 50% 40%, rgba(14,165,233,0.16), rgba(2,6,23,0.92))',
      boxShadow: '0 18px 50px rgba(2, 6, 23, 0.5)',
    }}>
      <div style={{ position: 'relative', width: '68px', height: '68px' }}>
        <span style={{
          position: 'absolute', inset: 0, borderRadius: '50%', border: '2px solid rgba(56, 189, 248, 0.2)', borderTopColor: '#38bdf8', animation: 'nifty-orbit-spin 1.2s linear infinite',
        }} />
        <span style={{
          position: 'absolute', inset: '11px', borderRadius: '50%', border: '2px solid rgba(34, 197, 94, 0.2)', borderTopColor: '#22c55e', animation: 'nifty-orbit-spin 0.9s linear infinite reverse',
        }} />
        <span style={{
          position: 'absolute', inset: '22px', borderRadius: '50%', background: 'linear-gradient(135deg, #22d3ee, #2563eb)', boxShadow: '0 0 20px rgba(56,189,248,0.75)',
        }} />
      </div>
      <div style={{ fontSize: '13px', fontWeight: 700, color: '#e2e8f0', letterSpacing: '0.02em' }}>{label}</div>
    </div>
  );
}

function InlineLoaderChip({ text = 'Updating...' }) {
  return (
    <span style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '3px 8px',
      borderRadius: '999px',
      border: '1px solid rgba(56, 189, 248, 0.3)',
      background: 'rgba(30, 41, 59, 0.68)',
      color: '#bae6fd',
      fontSize: '10px',
      fontWeight: 700,
    }}>
      <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#22d3ee', animation: 'nifty-pulse-dot 1s ease-in-out infinite' }} />
      {text}
    </span>
  );
}

function analyzeStrategy(strategy, metrics, t) {
  // t = theme tokens (optional, defaults to dark hex codes)
  const _green = t?.green || '#22c55e';
  const _red = t?.red || '#ef4444';
  const _yellow = t?.yellow || '#eab308';
  const _orange = t?.orange || '#f97316';
  const _blue = t?.blue || '#3b82f6';
  const closedLegs = strategy.closedLegs || [];
  const lotSize = Number(strategy.lotSize) || 65;
  const legs = strategy.legs || [];
  const realizedPL = closedLegs.reduce((sum, cl) => sum + (Number(cl.pnl) || 0), 0);
  const unrealizedPL = Number(metrics.markToMarket) || 0;
  const totalPL = realizedPL + unrealizedPL;

  const maxLoss = Math.abs(metrics.maxLoss);
  const currentLoss = unrealizedPL < 0 ? Math.abs(unrealizedPL) : 0;
  const riskConsumed = maxLoss > 0 ? Math.min(100, (currentLoss / maxLoss) * 100) : 0;

  const maxProfit = metrics.maxProfit;
  const currentProfit = unrealizedPL > 0 ? unrealizedPL : 0;
  const profitCaptured = maxProfit > 0 ? Math.min(100, (currentProfit / maxProfit) * 100) : 0;

  const entryNet = Math.abs(metrics.entryNetPremium) || 1;
  const premiumLeft = Number(metrics.premiumRemaining) || 0;
  const premiumDecayPct = metrics.entryNetPremium > 0
    ? Math.min(100, ((metrics.entryNetPremium - premiumLeft) / entryNet) * 100)
    : 0;

  const legBreakdown = legs.map((leg) => {
    const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
    const entry = Number(leg.premium) || 0;
    const current = Number(leg.marketPremium ?? leg.premium) || 0;
    const legMtm = leg.side === 'SELL'
      ? (entry - current) * qty * lotSize
      : (current - entry) * qty * lotSize;
    return { ...leg, entry, current, legMtm, qty, expiryLabel: formatExpiryDisplay(resolveLegExpiry(leg, strategy)) };
  });

  // ── Deep Risk Metrics ──
  const spotPrice = Number(strategy.currentSpot) || Number(strategy.savedAtSpot) || 0;
  const entrySpot = Number(strategy.savedAtSpot) || spotPrice;
  const spotMove = spotPrice - entrySpot;
  const spotMovePct = entrySpot > 0 ? ((spotMove / entrySpot) * 100) : 0;

  // Capital at risk = total premium paid for BUY legs + margin for SELL legs (approx)
  const buyPremiumPaid = legs.reduce((sum, l) => {
    const qty = Math.max(1, parseInt(l.quantity || 1, 10) || 1);
    return sum + (l.side === 'BUY' ? (Number(l.premium) || 0) * qty * lotSize : 0);
  }, 0);
  const sellPremiumReceived = legs.reduce((sum, l) => {
    const qty = Math.max(1, parseInt(l.quantity || 1, 10) || 1);
    return sum + (l.side === 'SELL' ? (Number(l.premium) || 0) * qty * lotSize : 0);
  }, 0);
  const netCapitalDeployed = buyPremiumPaid - sellPremiumReceived;
  const returnOnCapital = netCapitalDeployed > 0 ? ((totalPL / netCapitalDeployed) * 100) : (totalPL !== 0 ? 100 : 0);

  // Break-even distance from current spot
  const nearestBE = (metrics.breakEvens || []).length > 0
    ? metrics.breakEvens.reduce((closest, be) => Math.abs(be - spotPrice) < Math.abs(closest - spotPrice) ? be : closest, metrics.breakEvens[0])
    : null;
  const beDistance = nearestBE != null ? spotPrice - nearestBE : null;
  const beDistancePct = (nearestBE && nearestBE > 0) ? ((beDistance / nearestBE) * 100) : null;

  // Risk-reward ratio
  const riskReward = maxLoss > 0 ? (maxProfit / maxLoss) : (maxProfit > 0 ? Infinity : 0);

  // Position Greeks approximation
  const sellCount = legs.filter((l) => l.side === 'SELL').length;
  const buyCount = legs.filter((l) => l.side === 'BUY').length;
  const isNaked = sellCount > 0 && buyCount === 0;
  const isHedged = sellCount > 0 && buyCount > 0;
  const isLongOnly = buyCount > 0 && sellCount === 0;

  // Position type classification
  let positionType = 'Mixed';
  if (isNaked) positionType = '⚠️ Naked Sell';
  else if (isLongOnly) positionType = '🛡️ Long Only';
  else if (isHedged) positionType = '🔒 Hedged Spread';

  // Risk score (0-100, higher = more dangerous)
  let riskScore = 0;
  riskScore += riskConsumed * 0.35; // weight: current loss vs max loss
  riskScore += (isNaked ? 30 : isHedged ? 5 : 15); // naked positions are dangerous
  riskScore += Math.min(20, Math.abs(spotMovePct) * 2); // large spot moves increase risk
  if (premiumDecayPct < 30 && metrics.entryNetPremium > 0) riskScore += 5; // early in trade, more theta risk
  if (riskReward < 1 && riskReward > 0) riskScore += 10; // unfavorable R:R
  riskScore = Math.min(100, Math.max(0, riskScore));

  let riskLevel, riskColor;
  if (riskScore >= 70) { riskLevel = 'HIGH'; riskColor = _red; }
  else if (riskScore >= 40) { riskLevel = 'MEDIUM'; riskColor = _yellow; }
  else { riskLevel = 'LOW'; riskColor = _green; }

  let recommendation, reason, color;
  if (profitCaptured >= 80) {
    recommendation = '🟢 EXIT — Book Profits';
    reason = `${profitCaptured.toFixed(0)}% of max profit captured. Consider closing to lock in gains.`;
    color = _green;
  } else if (profitCaptured >= 50) {
    recommendation = '🟡 TRAIL — Protect Gains';
    reason = `${profitCaptured.toFixed(0)}% profit captured. Trail stop or close partial position.`;
    color = _yellow;
  } else if (riskConsumed >= 70) {
    recommendation = '🔴 HEDGE / EXIT — High Risk';
    reason = `${riskConsumed.toFixed(0)}% of max loss consumed. Add hedge or exit now.`;
    color = _red;
  } else if (riskConsumed >= 40) {
    recommendation = '🟠 WATCH — Rising Risk';
    reason = `${riskConsumed.toFixed(0)}% risk consumed. Monitor closely, prepare hedge.`;
    color = _orange;
  } else if (unrealizedPL >= 0) {
    recommendation = '🟢 HOLD — In Profit';
    reason = 'Position is profitable with manageable risk. Continue holding.';
    color = _green;
  } else {
    recommendation = '🔵 HOLD — Within Limits';
    reason = 'Loss is within acceptable range. Hold and monitor.';
    color = _blue;
  }

  const suggestions = [];
  if (profitCaptured >= 60 && profitCaptured < 80) {
    suggestions.push('Close winning legs and roll to new strikes for fresh premium');
  }
  if (riskConsumed >= 50) {
    const hasHedge = legs.some((l) => l.side === 'BUY');
    if (!hasHedge) suggestions.push('Add a protective BUY leg to cap further downside');
  }
  if (premiumDecayPct >= 70 && metrics.entryNetPremium > 0) {
    suggestions.push('Most time value decayed — premium sellers should consider exiting');
  }
  if (closedLegs.length > 0 && legs.length > 0) {
    suggestions.push(`${closedLegs.length} leg(s) already closed. Review if remaining legs still make sense standalone.`);
  }
  if (isNaked) {
    suggestions.push('⚠️ Position has naked SELL legs — unlimited risk. Add BUY hedge to limit downside.');
  }
  if (beDistance != null && Math.abs(beDistance) < spotPrice * 0.01) {
    suggestions.push('⚡ Spot is very close to break-even. Small moves can flip P/L quickly.');
  }
  if (riskReward < 1 && riskReward > 0 && unrealizedPL <= 0) {
    suggestions.push('Risk-reward is unfavorable (< 1:1). Consider restructuring the position.');
  }
  if (returnOnCapital < -30) {
    suggestions.push('💸 Return on capital below -30%. Cut the loss or hedge aggressively.');
  }

  return {
    realizedPL, unrealizedPL, totalPL,
    riskConsumed, profitCaptured, premiumDecayPct,
    premiumLeft, legBreakdown,
    recommendation, reason, color,
    suggestions, closedLegsCount: closedLegs.length,
    // new deep risk fields
    riskScore, riskLevel, riskColor,
    positionType, riskReward,
    returnOnCapital, netCapitalDeployed,
    buyPremiumPaid, sellPremiumReceived,
    nearestBE, beDistance, beDistancePct,
    spotMove, spotMovePct,
  };
}

function AxisPayoffChart({ points, minY, maxY, currentSpot, theme: t, styles }) {
  if (!points?.length) return <div style={styles.emptyChart}>No chart data</div>;

  const W = 400, H = 220;
  const pad = { left: 60, right: 16, top: 16, bottom: 36 };
  const cw = W - pad.left - pad.right;
  const ch = H - pad.top - pad.bottom;
  const minSpot = points[0].spot;
  const maxSpot = points[points.length - 1].spot;
  const xRange = maxSpot - minSpot || 1;
  const yMin = Math.min(minY, 0);
  const yMax = Math.max(maxY, 0);
  const yRange = yMax - yMin || 1;
  const xForSpot = (s) => pad.left + ((s - minSpot) / xRange) * cw;
  const yForValue = (v) => pad.top + ch - ((v - yMin) / yRange) * ch;
  const zeroY = yForValue(0);
  const spotX = xForSpot(currentSpot);

  const profitPath = points.map((p, i) => {
    const x = xForSpot(p.spot); const y = yForValue(Math.max(p.value, 0));
    return `${i === 0 ? 'M' : 'L'}${x},${y}`;
  }).join(' ') + ` L${xForSpot(maxSpot)},${zeroY} L${xForSpot(minSpot)},${zeroY} Z`;
  const lossPath = points.map((p, i) => {
    const x = xForSpot(p.spot); const y = yForValue(Math.min(p.value, 0));
    return `${i === 0 ? 'M' : 'L'}${x},${y}`;
  }).join(' ') + ` L${xForSpot(maxSpot)},${zeroY} L${xForSpot(minSpot)},${zeroY} Z`;
  const polyline = points.map((p) => `${xForSpot(p.spot)},${yForValue(p.value)}`).join(' ');

  const fmt = (v) => Math.abs(v) >= 100000 ? `${(v / 1000).toFixed(0)}k` : v.toLocaleString('en-IN');
  const yTickCount = 5;
  const yTicks = Array.from({ length: yTickCount + 1 }, (_, i) => Math.round(yMin + (yRange * i / yTickCount)));
  const xTickCount = 5;
  const xTicks = Array.from({ length: xTickCount + 1 }, (_, i) => Math.round(minSpot + (xRange * i / xTickCount)));

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" style={{ width: '100%', height: 'auto', maxHeight: '260px', display: 'block' }}>
      <defs>
        <clipPath id="chartArea"><rect x={pad.left} y={pad.top} width={cw} height={ch} /></clipPath>
      </defs>
      {/* grid */}
      {yTicks.map((v) => <line key={`yg${v}`} x1={pad.left} y1={yForValue(v)} x2={W - pad.right} y2={yForValue(v)} stroke="rgba(148,163,184,0.12)" />)}
      {xTicks.map((s) => <line key={`xg${s}`} x1={xForSpot(s)} y1={pad.top} x2={xForSpot(s)} y2={H - pad.bottom} stroke="rgba(148,163,184,0.08)" />)}
      {/* fills */}
      <path d={profitPath} fill="rgba(34,197,94,0.15)" clipPath="url(#chartArea)" />
      <path d={lossPath} fill="rgba(248,113,113,0.15)" clipPath="url(#chartArea)" />
      {/* zero + spot */}
      <line x1={pad.left} y1={zeroY} x2={W - pad.right} y2={zeroY} stroke={t.textMuted} strokeDasharray="6 4" />
      <line x1={spotX} y1={pad.top} x2={spotX} y2={H - pad.bottom} stroke={t.cyan} strokeDasharray="6 3" />
      {/* curve */}
      <polyline fill="none" stroke={t.green} strokeWidth="2" points={polyline} clipPath="url(#chartArea)" />
      {/* Y axis */}
      <line x1={pad.left} y1={pad.top} x2={pad.left} y2={H - pad.bottom} stroke={t.textMuted} />
      {yTicks.map((v) => <text key={`yl${v}`} x={pad.left - 6} y={yForValue(v) + 4} fontSize="11" fill={t.textSecondary} textAnchor="end" fontFamily="monospace">{fmt(v)}</text>)}
      {/* X axis */}
      <line x1={pad.left} y1={H - pad.bottom} x2={W - pad.right} y2={H - pad.bottom} stroke={t.textMuted} />
      {xTicks.map((s) => <text key={`xl${s}`} x={xForSpot(s)} y={H - pad.bottom + 16} fontSize="11" fill={t.textSecondary} textAnchor="middle" fontFamily="monospace">{s.toLocaleString('en-IN')}</text>)}
      {/* spot label */}
      <text x={spotX} y={H - pad.bottom + 30} fontSize="10" fill={t.cyan} textAnchor="middle" fontFamily="monospace">Spot {Math.round(currentSpot).toLocaleString('en-IN')}</text>
      {/* axis labels */}
      <text x={8} y={pad.top + ch / 2} fontSize="10" fill={t.textMuted} textAnchor="middle" fontFamily="monospace" transform={`rotate(-90,8,${pad.top + ch / 2})`}>P/L (₹)</text>
    </svg>
  );
}

function ScenarioBarChart({ scenarios = [], styles, theme: t }) {
  if (!scenarios.length) return <div style={styles.emptyChart}>No scenario data</div>;

  const W = 400, H = 220;
  const pad = { left: 60, right: 16, top: 20, bottom: 36 };
  const cw = W - pad.left - pad.right;
  const ch = H - pad.top - pad.bottom;
  const maxAbs = Math.max(...scenarios.map((e) => Math.abs(e.value)), 1);
  const barW = cw / scenarios.length - 6;
  const zeroY = pad.top + ch / 2;
  const halfH = ch / 2;
  const fmt = (v) => Math.abs(v) >= 100000 ? `${(v / 1000).toFixed(0)}k` : v.toLocaleString('en-IN');
  const showDenseLabels = scenarios.length <= 11;
  const middleIndex = Math.floor(scenarios.length / 2);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" style={{ width: '100%', height: 'auto', maxHeight: '260px', display: 'block' }}>
      <line x1={pad.left} y1={zeroY} x2={W - pad.right} y2={zeroY} stroke={t.textMuted} strokeDasharray="6 4" />
      <line x1={pad.left} y1={pad.top} x2={pad.left} y2={H - pad.bottom} stroke={t.textMuted} />
      <text x={pad.left - 6} y={pad.top + 4} fontSize="10" fill={t.textSecondary} textAnchor="end" fontFamily="monospace">{fmt(Math.round(maxAbs))}</text>
      <text x={pad.left - 6} y={zeroY + 4} fontSize="10" fill={t.textSecondary} textAnchor="end" fontFamily="monospace">0</text>
      <text x={pad.left - 6} y={H - pad.bottom} fontSize="10" fill={t.textSecondary} textAnchor="end" fontFamily="monospace">{fmt(-Math.round(maxAbs))}</text>
      {scenarios.map((entry, i) => {
        const barH = Math.max(4, (Math.abs(entry.value) / maxAbs) * halfH);
        const x = pad.left + 4 + i * (barW + 6);
        const y = entry.value >= 0 ? zeroY - barH : zeroY;
        const showValueLabel = showDenseLabels || entry.isCurrent || i === 0 || i === scenarios.length - 1 || i === middleIndex;
        const showAxisLabel = showDenseLabels || entry.isCurrent || i % 2 === 0 || i === scenarios.length - 1;
        return (
          <g key={`${entry.spot}-${entry.offset}`}>
            <rect x={x} y={y} width={barW} height={barH} rx="3" fill={entry.value >= 0 ? t.green : t.red} opacity={entry.isCurrent ? 1 : 0.9}>
              <title>{`${entry.offset >= 0 ? '+' : ''}${entry.offset} pts • Spot ${entry.spot} • MTM ${formatCurrency(entry.value)} • Close ${formatCurrency(entry.closeValue)}`}</title>
            </rect>
            {showValueLabel ? (
              <text x={x + barW / 2} y={entry.value >= 0 ? y - 4 : y + barH + 12} fontSize="9" textAnchor="middle" fill={entry.value >= 0 ? t.green : t.red} fontFamily="monospace">{fmt(Math.round(entry.value))}</text>
            ) : null}
            {showAxisLabel ? (
              <text x={x + barW / 2} y={H - pad.bottom + 16} fontSize="10" textAnchor="middle" fill={entry.isCurrent ? t.cyan : t.textSecondary} fontFamily="monospace">{Math.round(entry.spot)}</text>
            ) : null}
          </g>
        );
      })}
      <text x={pad.left + cw / 2} y={H - 4} fontSize="10" textAnchor="middle" fill={t.textMuted} fontFamily="monospace">What-if Nifty Spot</text>
    </svg>
  );
}

function WhatIfScenarioGrid({ scenarios = [], styles, theme: t }) {
  if (!scenarios.length) return <div style={styles.emptyChart}>No what-if values available</div>;

  return (
    <div style={styles.whatIfGrid}>
      {scenarios.map((scenario) => (
        <div
          key={`what-if-${scenario.spot}-${scenario.offset}`}
          style={{
            ...styles.whatIfCard,
            borderColor: scenario.isCurrent ? t.cyan : styles.whatIfCard.borderColor,
            background: scenario.isCurrent ? `${t.cyan}12` : styles.whatIfCard.background,
          }}
        >
          <div style={styles.whatIfTopRow}>
            <div style={styles.whatIfSpot}>Nifty {Math.round(scenario.spot).toLocaleString('en-IN')}</div>
            <div style={{ ...styles.whatIfOffset, color: scenario.offset > 0 ? t.green : scenario.offset < 0 ? t.red : t.cyan }}>
              {scenario.offset > 0 ? '+' : ''}{Math.round(scenario.offset)}
            </div>
          </div>
          <div style={styles.whatIfLabel}>Projected MTM</div>
          <div style={{ ...styles.whatIfValue, color: scenario.value >= 0 ? t.green : t.red }}>
            {formatCurrency(scenario.value)}
          </div>
          <div style={styles.whatIfSubLabel}>Close value {formatCurrency(scenario.closeValue)}</div>
        </div>
      ))}
    </div>
  );
}

function LegEditor({ draft, strategy, styles, theme: t, title, onFieldChange, onSave, onCancel }) {
  const strikeOptions = getLegCatalogOptions(strategy, draft.optionType);
  const selectedOption = getLegCatalogOption(strategy, draft.optionType, draft.strike, draft.expiry);
  const expiryOptions = getLegEditorExpiryOptions(strategy);

  return (
    <div style={styles.legEditor} className="nifty-leg-editor">
      <div style={styles.legEditorHeaderRow}>
        <div>
          <div style={styles.legEditorTitle}>{title}</div>
          <div style={styles.legEditorHint}>Choose from live strikes, then adjust the entry premium only if your fill was different.</div>
        </div>
        <div style={styles.legEditorSpot}>Spot {Math.round(Number(strategy.currentSpot || strategy.savedAtSpot || 0)).toLocaleString('en-IN')}</div>
      </div>
      <div style={styles.legEditorRow} className="nifty-leg-editor-row">
        <select value={draft.side} onChange={(e) => onFieldChange({ side: e.target.value })} style={styles.addLegSelect}>
          <option value="BUY">BUY</option>
          <option value="SELL">SELL</option>
        </select>
        <select value={draft.optionType} onChange={(e) => onFieldChange({ optionType: e.target.value })} style={styles.addLegSelect}>
          <option value="CE">CE</option>
          <option value="PE">PE</option>
        </select>
        <select value={draft.expiry} onChange={(e) => onFieldChange({ expiry: e.target.value })} style={{ ...styles.addLegSelect, minWidth: '150px' }}>
          {expiryOptions.map((expiry) => (
            <option key={`expiry-${expiry}`} value={expiry}>
              {formatExpiryDisplay(expiry)}
            </option>
          ))}
        </select>
        <select value={draft.strike} onChange={(e) => onFieldChange({ strike: e.target.value })} style={{ ...styles.addLegSelect, minWidth: '190px' }}>
          {strikeOptions.map((entry) => (
            <option key={`${draft.optionType}-${entry.strike}`} value={entry.strike}>
              {entry.strike} {entry.premium != null ? `• Live ${entry.premium.toFixed(2)}` : '• No live premium'}
            </option>
          ))}
        </select>
        <select value={draft.quantity} onChange={(e) => onFieldChange({ quantity: e.target.value })} style={styles.addLegSelect}>
          {LEG_QUANTITY_OPTIONS.map((qty) => <option key={qty} value={qty}>{qty} lot</option>)}
        </select>
        <input
          type="number"
          step="0.05"
          value={draft.premium}
          onChange={(e) => onFieldChange({ premium: e.target.value })}
          style={{ ...styles.addLegInput, width: '110px' }}
          placeholder="Entry"
        />
      </div>
      <div style={styles.legEditorMeta}>
        <span>Live premium: <strong>{selectedOption?.premium != null ? Number(selectedOption.premium).toFixed(2) : '—'}</strong></span>
        <span>Current value: <strong>{draft.marketPremium !== undefined && draft.marketPremium !== '' ? Number(draft.marketPremium).toFixed(2) : (draft.premium !== undefined && draft.premium !== '' ? Number(draft.premium).toFixed(2) : '—')}</strong></span>
      </div>
      <div style={styles.addLegActions}>
        <button onClick={onSave} style={styles.closeLegConfirm}>{draft.legId != null ? 'Save Leg' : 'Add Leg'}</button>
        <button onClick={onCancel} style={styles.closeLegCancel}>Cancel</button>
      </div>
    </div>
  );
}

function summarizeClosedStrategy(strategy) {
  const closedLegs = strategy.closedLegs || [];
  const transactions = [...(strategy.transactions || [])].sort((left, right) => new Date(left.timestamp || 0).getTime() - new Date(right.timestamp || 0).getTime());
  const grossRealizedPL = closedLegs.reduce((sum, leg) => sum + (Number(leg.pnl) || 0), 0);
  const transactionCost = calculateTransactionCost(transactions);
  const realizedPL = grossRealizedPL - transactionCost;
  const wins = closedLegs.filter((leg) => Number(leg.pnl) >= 0).length;
  const losses = Math.max(0, closedLegs.length - wins);
  const bestLeg = closedLegs.reduce((best, leg) => ((best == null || Number(leg.pnl) > Number(best.pnl)) ? leg : best), null);
  const worstLeg = closedLegs.reduce((worst, leg) => ((worst == null || Number(leg.pnl) < Number(worst.pnl)) ? leg : worst), null);
  const cumulativeTransactions = [];
  let runningTotal = 0;

  transactions.forEach((tx, index) => {
    runningTotal += (Number(tx.amount) || 0) - TRANSACTION_COST_PER_ORDER;
    cumulativeTransactions.push({
      label: tx.type || `Tx ${index + 1}`,
      value: Number(runningTotal.toFixed(2)),
      amount: Number((Number(tx.amount) || 0).toFixed(2)),
      cost: TRANSACTION_COST_PER_ORDER,
      timestamp: tx.timestamp,
    });
  });

  return {
    grossRealizedPL: Number(grossRealizedPL.toFixed(2)),
    transactionCost: Number(transactionCost.toFixed(2)),
    realizedPL: Number(realizedPL.toFixed(2)),
    wins,
    losses,
    bestLeg,
    worstLeg,
    legBars: closedLegs.map((leg, index) => ({
      label: `${leg.optionType} ${leg.strike}`,
      subtitle: `${leg.side} ${leg.quantity}L`,
      value: Number((Number(leg.pnl) || 0).toFixed(2)),
      key: `${leg.legId || index}-${leg.strike}`,
    })),
    cumulativeTransactions,
    transactions,
  };
}

function ClosedLegPnLChart({ items = [], styles, theme: t }) {
  if (!items.length) return <div style={styles.emptyChart}>No closed-leg P/L available</div>;

  const scale = Math.max(...items.map((item) => Math.abs(item.value)), 1);
  return (
    <div style={styles.closedBars}>
      {items.map((item) => {
        const width = `${Math.max(8, (Math.abs(item.value) / scale) * 100)}%`;
        const positive = item.value >= 0;
        return (
          <div key={item.key} style={styles.closedBarRow}>
            <div style={styles.closedBarLabelWrap}>
              <div style={styles.closedBarLabel}>{item.label}</div>
              <div style={styles.closedBarSub}>{item.subtitle}</div>
            </div>
            <div style={styles.closedBarTrack}>
              <div style={{ ...styles.closedBarFill, width, background: positive ? t.green : t.red }} />
            </div>
            <div style={{ ...styles.closedBarValue, color: positive ? t.green : t.red }}>{formatCurrency(item.value)}</div>
          </div>
        );
      })}
    </div>
  );
}

function ClosedCumulativeChart({ items = [], styles, theme: t }) {
  if (!items.length) return <div style={styles.emptyChart}>No transaction flow available</div>;

  const W = 400, H = 220;
  const pad = { left: 44, right: 14, top: 16, bottom: 34 };
  const cw = W - pad.left - pad.right;
  const ch = H - pad.top - pad.bottom;
  const minY = Math.min(0, ...items.map((item) => item.value));
  const maxY = Math.max(0, ...items.map((item) => item.value));
  const yRange = maxY - minY || 1;
  const xFor = (index) => pad.left + ((items.length === 1 ? 0 : index / (items.length - 1)) * cw);
  const yFor = (value) => pad.top + ch - (((value - minY) / yRange) * ch);
  const polyline = items.map((item, index) => `${xFor(index)},${yFor(item.value)}`).join(' ');
  const zeroY = yFor(0);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" style={{ width: '100%', height: 'auto', maxHeight: '240px', display: 'block' }}>
      <line x1={pad.left} y1={zeroY} x2={W - pad.right} y2={zeroY} stroke={t.textMuted} strokeDasharray="6 4" />
      <polyline fill="none" stroke={items[items.length - 1].value >= 0 ? t.green : t.red} strokeWidth="2.5" points={polyline} />
      {items.map((item, index) => (
        <g key={`${item.label}-${index}`}>
          <circle cx={xFor(index)} cy={yFor(item.value)} r="3.5" fill={item.value >= 0 ? t.green : t.red}>
            <title>{`${item.label}: ${formatCurrency(item.amount)} | Running ${formatCurrency(item.value)}`}</title>
          </circle>
          <text x={xFor(index)} y={H - 10} fontSize="9" fill={t.textSecondary} textAnchor="middle" fontFamily="monospace">{index + 1}</text>
        </g>
      ))}
      <text x={pad.left - 6} y={pad.top + 4} fontSize="10" fill={t.textSecondary} textAnchor="end" fontFamily="monospace">{Math.round(maxY).toLocaleString('en-IN')}</text>
      <text x={pad.left - 6} y={zeroY + 4} fontSize="10" fill={t.textSecondary} textAnchor="end" fontFamily="monospace">0</text>
      <text x={pad.left - 6} y={H - pad.bottom + 4} fontSize="10" fill={t.textSecondary} textAnchor="end" fontFamily="monospace">{Math.round(minY).toLocaleString('en-IN')}</text>
      <text x={pad.left + cw / 2} y={H - 2} fontSize="10" fill={t.textMuted} textAnchor="middle" fontFamily="monospace">Transaction sequence</text>
    </svg>
  );
}

function ClosedStrategyPanel({ strategy, styles, theme: t }) {
  const summary = summarizeClosedStrategy(strategy);

  return (
    <>
      <div style={{ ...styles.closedHero, borderColor: summary.realizedPL >= 0 ? t.greenDim : t.redDim, background: summary.realizedPL >= 0 ? `${t.green}12` : `${t.red}12` }}>
        <div>
          <div style={styles.closedHeroLabel}>Closed Strategy Net Profit</div>
          <div style={{ ...styles.closedHeroValue, color: summary.realizedPL >= 0 ? t.green : t.red }}>
            {summary.realizedPL >= 0 ? '+' : ''}{formatCurrency(summary.realizedPL)}
          </div>
        </div>
        <div style={styles.closedHeroStats}>
          <div><span style={styles.closedHeroKey}>Closed legs:</span> <strong>{summary.legBars.length}</strong></div>
          <div><span style={styles.closedHeroKey}>Wins / Losses:</span> <strong>{summary.wins} / {summary.losses}</strong></div>
          <div><span style={styles.closedHeroKey}>Transactions:</span> <strong>{summary.transactions.length}</strong></div>
        </div>
      </div>

      <div style={styles.metricsGrid} className="nifty-metrics-grid">
        <div style={styles.metricBox}><div style={styles.metricLabel}>Gross Profit</div><div style={{ ...styles.metricValue, color: summary.grossRealizedPL >= 0 ? t.green : t.red }}>{formatCurrency(summary.grossRealizedPL)}</div></div>
        <div style={styles.metricBox}><div style={styles.metricLabel}>Transaction Cost</div><div style={{ ...styles.metricValue, color: t.red }}>{formatCurrency(summary.transactionCost)}</div><div style={styles.metricSub}>{summary.transactions.length} × {formatCurrency(TRANSACTION_COST_PER_ORDER)}</div></div>
        <div style={styles.metricBox}><div style={styles.metricLabel}>Net Profit</div><div style={{ ...styles.metricValue, color: summary.realizedPL >= 0 ? t.green : t.red }}>{formatCurrency(summary.realizedPL)}</div></div>
        <div style={styles.metricBox}><div style={styles.metricLabel}>Closed At Spot</div><div style={styles.metricValue}>{formatCurrency(strategy.currentSpot || strategy.savedAtSpot)}</div></div>
        <div style={styles.metricBox}><div style={styles.metricLabel}>Best Leg</div><div style={{ ...styles.metricValue, color: t.green, fontSize: '14px' }}>{summary.bestLeg ? `${summary.bestLeg.optionType} ${summary.bestLeg.strike}` : '—'}</div><div style={styles.metricSub}>{summary.bestLeg ? formatCurrency(summary.bestLeg.pnl) : 'No data'}</div></div>
        <div style={styles.metricBox}><div style={styles.metricLabel}>Worst Leg</div><div style={{ ...styles.metricValue, color: t.red, fontSize: '14px' }}>{summary.worstLeg ? `${summary.worstLeg.optionType} ${summary.worstLeg.strike}` : '—'}</div><div style={styles.metricSub}>{summary.worstLeg ? formatCurrency(summary.worstLeg.pnl) : 'No data'}</div></div>
      </div>

      {(strategy.transactions || []).length > 0 && (
        <details style={styles.txDetails} open>
          <summary style={styles.txSummary}>Transactions ({strategy.transactions.length})</summary>
          <div style={styles.txList}>
            {strategy.transactions.map((tx, idx) => (
              <div key={idx} style={styles.txRow} className="nifty-tx-row">
                <span style={styles.txType}>{tx.type}</span>
                <span style={styles.txDesc}>{tx.description}</span>
                <span style={{ ...styles.txAmount, color: (tx.amount || 0) >= 0 ? t.green : t.red }} className="nifty-tx-amount">
                  {formatCurrency(tx.amount || 0)}
                </span>
                <span style={styles.txTime}>{new Date(tx.timestamp).toLocaleString('en-IN')}</span>
              </div>
            ))}
          </div>
        </details>
      )}
    </>
  );
}

function PremiumBars({ metrics, styles, theme: t }) {
  const items = [
    { label: 'Entry net', value: metrics.entryNetPremium, color: t.blue },
    { label: 'Close value', value: metrics.liveCloseValue, color: t.purple },
    { label: 'Captured', value: metrics.capturedPremium, color: t.green },
    { label: 'Live MTM', value: metrics.markToMarket, color: metrics.markToMarket >= 0 ? t.green : t.red },
  ];
  const scale = Math.max(...items.map((item) => Math.abs(Number(item.value) || 0)), 1);

  return (
    <div style={styles.premiumList}>
      {items.map((item) => {
        const width = `${Math.max(6, (Math.abs(Number(item.value) || 0) / scale) * 100)}%`;
        return (
          <div key={item.label} style={styles.premiumRow} className="nifty-premium-row" title={`${item.label}: ${formatCurrency(item.value)}`}>
            <div style={styles.premiumLabel}>{item.label}</div>
            <div style={styles.premiumTrack}>
              <div style={{ ...styles.premiumFill, width, background: item.color }} />
            </div>
            <div style={{ ...styles.premiumValue, color: item.color }}>{formatCurrency(item.value)}</div>
          </div>
        );
      })}
    </div>
  );
}

function RangeBandChart({ metrics, currentSpot, styles }) {
  const points = metrics.points || [];
  if (!points.length) return <div style={styles.emptyChart}>No range data</div>;

  const start = points[0].spot;
  const end = points[points.length - 1].spot;
  const totalRange = end - start || 1;
  const leftPct = (value) => Math.max(0, Math.min(100, ((Number(value) - start) / totalRange) * 100));

  const parseZones = (value) => {
    if (!value || value === 'None') return [];
    return value.split(',').map((part) => {
      const [from, to] = part.trim().split('–').map((item) => Number(item));
      return Number.isFinite(from) && Number.isFinite(to) ? { from, to } : null;
    }).filter(Boolean);
  };

  const profitZones = parseZones(metrics.profitRange);
  const lossZones = parseZones(metrics.lossRange);

  return (
    <div>
      <div style={styles.rangeWrap}>
        <div style={styles.rangeTrack} />
        {lossZones.map((zone, index) => (
          <div
            key={`loss-${zone.from}-${zone.to}-${index}`}
            style={{
              ...styles.rangeSeg,
              left: `${leftPct(zone.from)}%`,
              width: `${Math.max(2, leftPct(zone.to) - leftPct(zone.from))}%`,
              background: '#b91c1c',
            }}
            title={`Loss zone ${zone.from} to ${zone.to}`}
          />
        ))}
        {profitZones.map((zone, index) => (
          <div
            key={`profit-${zone.from}-${zone.to}-${index}`}
            style={{
              ...styles.rangeSeg,
              left: `${leftPct(zone.from)}%`,
              width: `${Math.max(2, leftPct(zone.to) - leftPct(zone.from))}%`,
              background: '#15803d',
            }}
            title={`Profit zone ${zone.from} to ${zone.to}`}
          />
        ))}
        <div style={{ ...styles.rangeMarker, left: `${leftPct(currentSpot)}%` }} title={`Current spot ${Math.round(currentSpot)}`} />
      </div>
      <div style={styles.rangeAxis}>
        <span>{start}</span>
        <span>Spot {Math.round(currentSpot)}</span>
        <span>{end}</span>
      </div>
    </div>
  );
}

function StrategyAnalyzer({ strategy, metrics, styles, theme: t }) {
  const analysis = analyzeStrategy(strategy, metrics, t);
  return (
    <div style={styles.analyzerWrap}>
      {/* ── Risk Score Banner ── */}
      <div style={{ ...styles.riskBanner, borderColor: analysis.riskColor, background: `${analysis.riskColor}10` }}>
        <div style={styles.riskBannerLeft}>
          <div style={{ ...styles.riskScoreCircle, borderColor: analysis.riskColor, color: analysis.riskColor }}>
            {analysis.riskScore.toFixed(0)}
          </div>
          <div>
            <div style={{ ...styles.riskLevelLabel, color: analysis.riskColor }}>
              Risk: {analysis.riskLevel}
            </div>
            <div style={styles.riskPosType}>{analysis.positionType}</div>
          </div>
        </div>
        <div style={{ ...styles.analyzerRec, color: analysis.color, borderColor: analysis.color }}>
          {analysis.recommendation}
        </div>
      </div>
      <div style={styles.analyzerReason}>{analysis.reason}</div>

      {/* ── P/L Cards ── */}
      <div style={styles.analyzerGrid} className="nifty-analyzer-grid">
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${analysis.unrealizedPL >= 0 ? t.green : t.red}` }}>
          <div style={styles.analyzerLabel}>Unrealized P/L</div>
          <div style={{ ...styles.analyzerValue, color: analysis.unrealizedPL >= 0 ? t.green : t.red }}>
            {formatCurrency(analysis.unrealizedPL)}
          </div>
        </div>
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${analysis.realizedPL >= 0 ? t.green : t.red}` }}>
          <div style={styles.analyzerLabel}>Realized P/L</div>
          <div style={{ ...styles.analyzerValue, color: analysis.realizedPL >= 0 ? t.green : t.red }}>
            {formatCurrency(analysis.realizedPL)}
          </div>
        </div>
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${analysis.totalPL >= 0 ? t.green : t.red}`, background: `${analysis.totalPL >= 0 ? t.green : t.red}08` }}>
          <div style={styles.analyzerLabel}>Total P/L</div>
          <div style={{ ...styles.analyzerValue, color: analysis.totalPL >= 0 ? t.green : t.red, fontSize: '18px' }}>
            {formatCurrency(analysis.totalPL)}
          </div>
        </div>
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${t.purple}` }}>
          <div style={styles.analyzerLabel}>Premium Left</div>
          <div style={styles.analyzerValue}>{formatCurrency(analysis.premiumLeft)}</div>
          <div style={styles.analyzerSub}>{(analysis.premiumLeft / (Number(strategy.lotSize) || 65)).toFixed(2)} pts × {Number(strategy.lotSize) || 65} lot</div>
        </div>
      </div>

      {/* ── Deep Risk Metrics ── */}
      <div style={styles.analyzerGrid} className="nifty-analyzer-grid">
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${t.yellow}` }}>
          <div style={styles.analyzerLabel}>Risk : Reward</div>
          <div style={{ ...styles.analyzerValue, color: analysis.riskReward >= 1 ? t.green : t.yellow }}>
            {analysis.riskReward === Infinity ? '∞' : `1 : ${analysis.riskReward.toFixed(2)}`}
          </div>
        </div>
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${analysis.returnOnCapital >= 0 ? t.green : t.red}` }}>
          <div style={styles.analyzerLabel}>Return on Capital</div>
          <div style={{ ...styles.analyzerValue, color: analysis.returnOnCapital >= 0 ? t.green : t.red }}>
            {analysis.returnOnCapital >= 0 ? '+' : ''}{analysis.returnOnCapital.toFixed(1)}%
          </div>
          <div style={styles.analyzerSub}>Capital: {formatCurrency(Math.abs(analysis.netCapitalDeployed))}</div>
        </div>
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${t.cyan}` }}>
          <div style={styles.analyzerLabel}>Nearest Break-even</div>
          <div style={styles.analyzerValue}>{analysis.nearestBE != null ? analysis.nearestBE.toLocaleString('en-IN') : '—'}</div>
          {analysis.beDistance != null && (
            <div style={{ ...styles.analyzerSub, color: analysis.beDistance > 0 ? t.green : t.red }}>
              {analysis.beDistance > 0 ? '▲' : '▼'} {Math.abs(analysis.beDistance).toFixed(0)} pts ({analysis.beDistancePct > 0 ? '+' : ''}{analysis.beDistancePct.toFixed(2)}%)
            </div>
          )}
        </div>
        <div style={{ ...styles.analyzerCard, borderLeft: `3px solid ${analysis.spotMovePct >= 0 ? t.green : t.red}` }}>
          <div style={styles.analyzerLabel}>Spot Move Since Entry</div>
          <div style={{ ...styles.analyzerValue, color: analysis.spotMovePct >= 0 ? t.green : t.red }}>
            {analysis.spotMove >= 0 ? '+' : ''}{analysis.spotMove.toFixed(0)}
          </div>
          <div style={styles.analyzerSub}>{analysis.spotMovePct >= 0 ? '+' : ''}{analysis.spotMovePct.toFixed(2)}%</div>
        </div>
      </div>

      {/* ── Gauge Bars ── */}
      <div style={styles.analyzerGrid} className="nifty-analyzer-grid">
        <div style={styles.analyzerCard}>
          <div style={styles.analyzerLabel}>Risk Consumed</div>
          <div style={styles.gaugeWrap}>
            <div style={{ ...styles.gaugeBar, width: `${Math.min(analysis.riskConsumed, 100)}%`, background: analysis.riskConsumed >= 70 ? t.red : analysis.riskConsumed >= 40 ? t.orange : t.green }} />
          </div>
          <div style={{ ...styles.analyzerSub, color: analysis.riskConsumed >= 70 ? t.red : t.textSecondary }}>
            {analysis.riskConsumed.toFixed(1)}% of max loss ({formatCurrency(Math.abs(metrics.maxLoss))})
          </div>
        </div>
        <div style={styles.analyzerCard}>
          <div style={styles.analyzerLabel}>Profit Captured</div>
          <div style={styles.gaugeWrap}>
            <div style={{ ...styles.gaugeBar, width: `${Math.min(analysis.profitCaptured, 100)}%`, background: t.green }} />
          </div>
          <div style={styles.analyzerSub}>{analysis.profitCaptured.toFixed(1)}% of max profit ({formatCurrency(metrics.maxProfit)})</div>
        </div>
        <div style={styles.analyzerCard}>
          <div style={styles.analyzerLabel}>Premium Decay</div>
          <div style={styles.gaugeWrap}>
            <div style={{ ...styles.gaugeBar, width: `${Math.min(Math.max(analysis.premiumDecayPct, 0), 100)}%`, background: t.purple }} />
          </div>
          <div style={styles.analyzerSub}>{analysis.premiumDecayPct.toFixed(1)}% time value decayed</div>
        </div>
      </div>

      <div style={styles.analyzerSection}>
        <div style={styles.analyzerSubTitle}>Per-Leg P/L</div>
        <div style={styles.legBreakdownTable}>
          {analysis.legBreakdown.map((leg) => (
            <div key={`lb-${leg.id}-${leg.strike}`} style={styles.legBreakdownRow} className="nifty-leg-breakdown">
              <span style={styles.legBreakdownLabel}>
                {leg.side} {leg.qty}L {leg.optionType} {leg.strike} ({leg.expiryLabel})
              </span>
              <span style={styles.legBreakdownPrices} className="nifty-leg-prices">
                Entry: {leg.entry.toFixed(2)} → Now: {leg.current.toFixed(2)}
              </span>
              <span style={{ ...styles.legBreakdownPL, color: leg.legMtm >= 0 ? t.green : t.red }} className="nifty-leg-pl">
                {leg.legMtm >= 0 ? '+' : ''}{formatCurrency(leg.legMtm)}
              </span>
            </div>
          ))}
        </div>
      </div>

      {(strategy.closedLegs || []).length > 0 && (
        <div style={styles.analyzerSection}>
          <div style={styles.analyzerSubTitle}>Closed Positions ({strategy.closedLegs.length})</div>
          <div style={styles.legBreakdownTable}>
            {strategy.closedLegs.map((cl, idx) => (
              <div key={`cl-${idx}`} style={styles.legBreakdownRow} className="nifty-leg-breakdown">
                <span style={styles.legBreakdownLabel}>
                  {cl.side} {cl.quantity}L {cl.optionType} {cl.strike} ({formatExpiryDisplay(cl.expiry)})
                </span>
                <span style={styles.legBreakdownPrices} className="nifty-leg-prices">
                  {cl.entryPremium.toFixed(2)} → {cl.exitPremium.toFixed(2)}
                </span>
                <span style={{ ...styles.legBreakdownPL, color: cl.pnl >= 0 ? t.green : t.red }} className="nifty-leg-pl">
                  {cl.pnl >= 0 ? '+' : ''}{formatCurrency(cl.pnl)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {analysis.suggestions.length > 0 && (
        <div style={styles.analyzerSection}>
          <div style={styles.analyzerSubTitle}>💡 Suggestions</div>
          <ul style={styles.suggestionList}>
            {analysis.suggestions.map((s, i) => <li key={i} style={styles.suggestionItem}>{s}</li>)}
          </ul>
        </div>
      )}

      {(strategy.transactions || []).length > 0 && (
        <details style={styles.txDetails}>
          <summary style={styles.txSummary}>📋 Transaction History ({strategy.transactions.length})</summary>
          <div style={styles.txList}>
            {strategy.transactions.map((tx, idx) => (
              <div key={idx} style={styles.txRow} className="nifty-tx-row">
                <span style={styles.txType}>{tx.type}</span>
                <span style={styles.txDesc}>{tx.description}</span>
                <span style={{ ...styles.txAmount, color: (tx.amount || 0) >= 0 ? t.green : t.red }} className="nifty-tx-amount">
                  {formatCurrency(tx.amount || 0)}
                </span>
                <span style={styles.txTime}>{new Date(tx.timestamp).toLocaleString('en-IN')}</span>
              </div>
            ))}
          </div>
        </details>
      )}
    </div>
  );
}

function formatLeg(leg) {
  const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
  return `${leg.side} ${qty} lot${qty > 1 ? 's' : ''} ${leg.optionType} ${leg.strike} ${formatExpiryDisplay(leg.expiry)} @ ${Number(leg.premium || 0).toFixed(2)}`;
}

function formatChartDate(value) {
  if (!value) return '-';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '-';
  return parsed.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
}

function toLocalDateTimeInputValue(value) {
  if (!value) return '';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '';
  const offsetMs = parsed.getTimezoneOffset() * 60000;
  return new Date(parsed.getTime() - offsetMs).toISOString().slice(0, 16);
}

function toIsoFromLocalDateTimeInputValue(value) {
  if (!value) return null;
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return null;
  return parsed.toISOString();
}

export default function NiftyStrategiesPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [savedStrategies, setSavedStrategies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [loadingIndices, setLoadingIndices] = useState(false);
  const [loadingStrategies, setLoadingStrategies] = useState(false);
  const [marketIndices, setMarketIndices] = useState([]);
  const [currentValuationSource, setCurrentValuationSource] = useState('live');
  const [refreshIntervalSeconds, setRefreshIntervalSeconds] = useState(60);
  const [refreshSession, setRefreshSession] = useState('nse');
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(true);
  const [pageVisible, setPageVisible] = useState(true);
  const [lastRefreshAt, setLastRefreshAt] = useState(null);
  const { theme, themeId } = useTheme();
  const styles = useMemo(() => applyTheme(darkStyles, themeId, theme), [themeId]);
  const marketIndicesRef = useRef([]);
  const refreshPromiseRef = useRef(null);

  useEffect(() => {
    marketIndicesRef.current = marketIndices;
  }, [marketIndices]);

  useEffect(() => {
    if (typeof document === 'undefined') return undefined;
    const syncVisibility = () => setPageVisible(!document.hidden);
    syncVisibility();
    document.addEventListener('visibilitychange', syncVisibility);
    return () => document.removeEventListener('visibilitychange', syncVisibility);
  }, []);

  const loadMarketIndices = useCallback(async () => {
    setLoadingIndices(true);
    try {
      const res = await fetch('/api/market-indices');
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Unable to load market indices.');
      }
      const nextIndices = data.indices || [];
      setMarketIndices(nextIndices);
      return nextIndices;
    } catch (_) {
      return marketIndicesRef.current;
    } finally {
      setLoadingIndices(false);
    }
  }, []);

  const enrichStrategies = useCallback(async (baseStrategies = [], options = {}) => {
    if (!baseStrategies.length) return [];

    const { includeWhatIf = true, fallbackIndices = marketIndicesRef.current } = options;
    const requestCache = new Map();
    const fetchJson = async (url) => {
      if (!requestCache.has(url)) {
        requestCache.set(url, (async () => {
          const response = await fetch(url);
          const data = await response.json();
          if (!response.ok) {
            throw new Error(data.error || 'Unable to load pricing data.');
          }
          return data;
        })());
      }
      return requestCache.get(url);
    };

    const fallbackNiftySpot = Number((fallbackIndices.find((index) => index.key === 'NIFTY50')?.price) || 0);

    return Promise.all(baseStrategies.map(async (strategy) => {
      const isClosed = strategy.status === 'closed';
      const strategyPricingSource = strategy.pricingSource || 'blend';
      const valuationSource = currentValuationSource || 'live';
      let currentSpot = Number(strategy.currentSpot || strategy.whatIfBaseSpot || strategy.savedAtSpot || 0);
      let liveSource = strategy.liveSource || 'saved';
      let chainMap = { CE: {}, PE: {}, byExpiry: {} };
      let whatIfScenarios = Array.isArray(strategy.whatIfScenarios) ? strategy.whatIfScenarios : [];
      let whatIfBaseSpot = buildWhatIfBaseSpot(currentSpot);
      let availableExpiries = [...new Set((strategy.availableExpiries || []).map((expiry) => Number(expiry)).filter((expiry) => Number.isFinite(expiry) && expiry > 0))].sort((left, right) => left - right);

      if (isClosed) {
        const lotSize = Number(strategy.lotSize) || 65;
        const closedLegs = syncLegsWithChain(strategy.legs || [], chainMap);
        return {
          ...strategy,
          currentSpot: Number(strategy.savedAtSpot || currentSpot || fallbackNiftySpot || 0),
          liveSource,
          currentValuationSource: valuationSource,
          strategyPricingSource,
          availableExpiries: getStrategyExpiries(strategy),
          liveChainMap: chainMap,
          legCatalog: buildLegCatalog(chainMap, currentSpot, strategy.legs || []),
          whatIfBaseSpot,
          whatIfScenarios: [],
          liveMetrics: strategy.liveMetrics || computeStrategyMetrics(closedLegs, lotSize, Number(strategy.savedAtSpot || currentSpot || 0)),
          legs: closedLegs,
        };
      }

      try {
        if (!availableExpiries.length) {
          try {
            const expiryUniverseResponse = await fetch(buildExpiryUniverseUrl(strategy));
            const expiryUniverseData = await expiryUniverseResponse.json();
            if (expiryUniverseResponse.ok && Array.isArray(expiryUniverseData.expirations)) {
              availableExpiries = [...new Set(expiryUniverseData.expirations.map((expiry) => Number(expiry)).filter((expiry) => Number.isFinite(expiry) && expiry > 0))].sort((left, right) => left - right);
            }
          } catch (_) { /* ignore */ }
        }

        const formulaResponse = await fetch(buildExpectedPricingUrl(strategy, availableExpiries));
        const formulaData = await formulaResponse.json();
        if (!formulaResponse.ok) {
          throw new Error(formulaData.error || 'Unable to load formula prices.');
        }

        currentSpot = Number(formulaData.referenceSpot || formulaData.liveSpot || fallbackNiftySpot || currentSpot || 0);
        liveSource = `${getPricingSourceLabel(valuationSource)} / current valuation`;
        (formulaData.contracts || []).forEach((contract) => {
          if (!chainMap[contract.type]) return;
          const premium = resolveExpectedOptionPrice(contract, valuationSource);
          const strike = Number(contract.strike);
          const expiry = Number(contract.expiryUnix) || 0;
          chainMap[contract.type][strike] = premium;
          if (expiry > 0) {
            if (!chainMap.byExpiry[expiry]) chainMap.byExpiry[expiry] = { CE: {}, PE: {} };
            chainMap.byExpiry[expiry][contract.type][strike] = premium;
          }
        });

        whatIfBaseSpot = buildWhatIfBaseSpot(currentSpot);
        if (includeWhatIf) {
          try {
            const scenarioData = await fetchJson(buildWhatIfPricingUrl(strategy, currentSpot));
          whatIfScenarios = computeProjectedScenarioValues(
            strategy.legs || [],
            Number(strategy.lotSize) || 65,
            scenarioData.scenarioContracts || [],
            valuationSource,
            whatIfBaseSpot,
          );
          } catch (_) {
            whatIfScenarios = [];
          }
        }
      } catch (_) {
        try {
          const firstExpiry = getStrategyExpiries(strategy)[0];
          const query = firstExpiry ? `?symbol=NIFTY&expiry=${firstExpiry}` : '?symbol=NIFTY';
          const response = await fetch(`/api/options-chain${query}`);
          const data = await response.json();
          currentSpot = Number(data.spot || fallbackNiftySpot || currentSpot || 0);
          liveSource = data.source || liveSource;
          (data.strikes || []).forEach((item) => {
            if (!chainMap[item.type]) return;
            const strike = Number(item.strike);
            const premium = normalizePremium(item.price || item.lastPrice || item.bid || item.ask || 0);
            chainMap[item.type][strike] = premium;
            const expiry = Number(firstExpiry) || 0;
            if (expiry > 0) {
              if (!chainMap.byExpiry[expiry]) chainMap.byExpiry[expiry] = { CE: {}, PE: {} };
              chainMap.byExpiry[expiry][item.type][strike] = premium;
            }
          });
        } catch (_) {
          if (fallbackNiftySpot > 0) {
            currentSpot = fallbackNiftySpot;
            liveSource = 'market-indices fallback';
          }
          chainMap = { CE: {}, PE: {}, byExpiry: {} };
        }
      }

      const lotSize = Number(strategy.lotSize) || 65;
      const hasFreshChainData = Object.keys(chainMap.CE).length > 0 || Object.keys(chainMap.PE).length > 0;
      const liveLegs = syncLegsWithChain(strategy.legs || [], chainMap);
      return {
        ...strategy,
        currentSpot,
        liveSource,
        currentValuationSource: valuationSource,
        strategyPricingSource,
        availableExpiries: Array.from(new Set([
          ...availableExpiries,
          ...Object.keys(chainMap.byExpiry).map((value) => Number(value)).filter((value) => Number.isFinite(value) && value > 0),
        ])).sort((left, right) => left - right),
        liveChainMap: chainMap,
        legCatalog: buildLegCatalog(chainMap, currentSpot, strategy.legs || []),
        whatIfBaseSpot,
        whatIfScenarios,
        liveMetrics: hasFreshChainData || strategy.status !== 'closed'
          ? computeStrategyMetrics(liveLegs, lotSize, currentSpot)
          : (strategy.liveMetrics || computeStrategyMetrics(liveLegs, lotSize, currentSpot)),
        legs: liveLegs,
      };
    }));
  }, [currentValuationSource]);

  const loadSavedStrategies = useCallback(async ({ showSpinner = true, includeWhatIf = true, refreshIndices = false } = {}) => {
    if (refreshPromiseRef.current) return refreshPromiseRef.current;

    const request = (async () => {
      if (showSpinner) {
        setLoading(true);
      } else {
        setRefreshing(true);
      }
      setLoadingStrategies(true);
      setError('');
      try {
        const indices = refreshIndices ? await loadMarketIndices() : marketIndicesRef.current;
        const response = await fetch('/api/options-strategies');
        const data = await response.json();
        if (!response.ok) {
          throw new Error(data.error || 'Unable to load saved strategies.');
        }
        const enriched = await enrichStrategies(data.strategies || [], { includeWhatIf, fallbackIndices: indices });
        setSavedStrategies(enriched);
        setLastRefreshAt(new Date().toISOString());
      } catch (loadError) {
        setSavedStrategies([]);
        setError(loadError.message || 'Unable to load saved strategies.');
      } finally {
        setLoading(false);
        setRefreshing(false);
        setLoadingStrategies(false);
        refreshPromiseRef.current = null;
      }
    })();

    refreshPromiseRef.current = request;
    return request;
  }, [enrichStrategies, loadMarketIndices]);

  useEffect(() => {
    restoreUserSession(router, setUser);

    const storedValuationSource = localStorage.getItem('nifty-current-valuation-source');
    if (storedValuationSource && CURRENT_VALUATION_OPTIONS.includes(storedValuationSource)) {
      setCurrentValuationSource(storedValuationSource);
    }

    const storedRefreshInterval = Number(localStorage.getItem('nifty-refresh-interval-seconds') || '60');
    if (REFRESH_INTERVAL_OPTIONS.some((entry) => entry.value === storedRefreshInterval)) {
      setRefreshIntervalSeconds(storedRefreshInterval);
    }

    const storedRefreshSession = localStorage.getItem('nifty-refresh-session');
    if (MARKET_SESSION_OPTIONS.some((entry) => entry.value === storedRefreshSession)) {
      setRefreshSession(storedRefreshSession);
    }

    const storedAutoRefresh = localStorage.getItem('nifty-auto-refresh-enabled');
    if (storedAutoRefresh != null) {
      setAutoRefreshEnabled(storedAutoRefresh !== 'false');
    }
  }, [router]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    localStorage.setItem('nifty-current-valuation-source', currentValuationSource);
  }, [currentValuationSource]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    localStorage.setItem('nifty-refresh-interval-seconds', String(refreshIntervalSeconds));
  }, [refreshIntervalSeconds]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    localStorage.setItem('nifty-refresh-session', refreshSession);
  }, [refreshSession]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    localStorage.setItem('nifty-auto-refresh-enabled', String(autoRefreshEnabled));
  }, [autoRefreshEnabled]);

  useEffect(() => {
    if (!user) return;
    loadSavedStrategies({ showSpinner: true, includeWhatIf: true, refreshIndices: true });
  }, [user, loadSavedStrategies]);

  useEffect(() => {
    if (!user) return;
    loadSavedStrategies({ showSpinner: false, includeWhatIf: true, refreshIndices: false });
  }, [currentValuationSource, user, loadSavedStrategies]);

  useEffect(() => {
    if (!user || !autoRefreshEnabled || refreshIntervalSeconds <= 0) return undefined;

    const tick = () => {
      if (document.hidden) return;
      if (!isWithinMarketSession(refreshSession)) return;
      loadSavedStrategies({ showSpinner: false, includeWhatIf: true, refreshIndices: true });
    };

    const interval = setInterval(tick, refreshIntervalSeconds * 1000);
    return () => clearInterval(interval);
  }, [autoRefreshEnabled, refreshIntervalSeconds, refreshSession, user, loadSavedStrategies]);

  const refreshPauseReason = useMemo(() => getRefreshPauseReason({
    autoRefreshEnabled,
    refreshIntervalSeconds,
    refreshSession,
    pageVisible,
  }), [autoRefreshEnabled, refreshIntervalSeconds, refreshSession, pageVisible]);

  const refreshStatusLabel = useMemo(() => {
    if (refreshing) return 'Refreshing live data...';
    if (refreshPauseReason) return refreshPauseReason;
    const session = MARKET_SESSION_OPTIONS.find((entry) => entry.value === refreshSession);
    return `Auto refresh every ${refreshIntervalSeconds}s during ${session?.label || 'selected market'} hours`;
  }, [refreshIntervalSeconds, refreshPauseReason, refreshSession, refreshing]);

  const deleteSavedStrategy = async (id) => {
    if (!confirm('Delete this saved Nifty options strategy?')) return;
    try {
      const response = await fetch('/api/options-strategies', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Unable to delete strategy.');
      }
      const enriched = await enrichStrategies(data.strategies || []);
      setSavedStrategies(enriched);
    } catch (deleteError) {
      alert(deleteError.message || 'Unable to delete strategy.');
    }
  };

  const [closingLegInfo, setClosingLegInfo] = useState(null);
  const [closePrice, setClosePrice] = useState('');
  const [legEditor, setLegEditor] = useState(null);
  const [usePastActionDate, setUsePastActionDate] = useState({});
  const [actionDateTimeByStrategy, setActionDateTimeByStrategy] = useState({});
  const [learningModal, setLearningModal] = useState(null); // { strategyId, actionTimestamp, pendingCloseLeg? }
  const [learningText, setLearningText] = useState('');
  const [showEmbeddedBuilder, setShowEmbeddedBuilder] = useState(false);
  const [embeddedBuilderLoaded, setEmbeddedBuilderLoaded] = useState(false);
  const [embeddedBuilderStrategyId, setEmbeddedBuilderStrategyId] = useState(null);
  const [embeddedBuilderVersion, setEmbeddedBuilderVersion] = useState(0);

  const getActionTimestamp = (strategyId) => {
    if (!usePastActionDate[strategyId]) return new Date().toISOString();
    return toIsoFromLocalDateTimeInputValue(actionDateTimeByStrategy[strategyId]) || new Date().toISOString();
  };

  const togglePastActionDate = (strategyId, enabled) => {
    setUsePastActionDate((current) => ({ ...current, [strategyId]: enabled }));
    if (enabled) {
      setActionDateTimeByStrategy((current) => ({
        ...current,
        [strategyId]: current[strategyId] || toLocalDateTimeInputValue(new Date().toISOString()),
      }));
    }
  };

  const openLearningModal = (strategyId, actionTimestamp, pendingCloseLeg = null) => {
    setLearningText('');
    setLearningModal({ strategyId, actionTimestamp, pendingCloseLeg });
  };

  const submitLearningModal = (learning = null) => {
    if (!learningModal) return;
    if (learningModal.pendingCloseLeg) {
      closeLeg(
        learningModal.strategyId,
        learningModal.pendingCloseLeg.legId,
        learningModal.pendingCloseLeg.exitPrice,
        learningModal.actionTimestamp,
        learning,
      );
    } else {
      updateStrategyStatus(learningModal.strategyId, 'closed', learningModal.actionTimestamp, learning);
    }
    setLearningModal(null);
  };

  const openEmbeddedBuilder = useCallback((strategyId = null) => {
    if (strategyId == null) {
      try {
        sessionStorage.removeItem('nifty-strategy-legs');
        sessionStorage.removeItem('nifty-strategy-meta');
      } catch (_) {}
    }
    setEmbeddedBuilderLoaded(true);
    setEmbeddedBuilderStrategyId(strategyId);
    setEmbeddedBuilderVersion((current) => current + 1);
    setShowEmbeddedBuilder(true);
  }, []);

  const updateStrategyStatus = async (strategyId, newStatus, actionTimestamp = null, learning = null) => {
    const strategy = savedStrategies.find((s) => s.id === strategyId);
    if (!strategy) return;
    const eventTimestamp = actionTimestamp || new Date().toISOString();
    try {
      const response = await fetch('/api/options-strategies', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...strategy,
          status: newStatus,
          ...(learning ? { learning } : {}),
          transactions: [
            ...(strategy.transactions || []),
            { type: newStatus === 'active' ? 'BOUGHT' : 'STATUS', description: `Status → ${newStatus.toUpperCase()}`, amount: 0, timestamp: eventTimestamp },
          ],
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      const enriched = await enrichStrategies(data.strategies || []);
      setSavedStrategies(enriched);
    } catch (e) { alert(e.message); }
  };

  const closeLeg = async (strategyId, legId, exitPrice, actionTimestamp = null, learning = null) => {
    const strategy = savedStrategies.find((s) => s.id === strategyId);
    if (!strategy) return;
    const leg = (strategy.legs || []).find((l) => l.id === legId);
    if (!leg) return;
    const eventTimestamp = actionTimestamp || new Date().toISOString();
    const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
    const entry = Number(leg.premium) || 0;
    const exit = Number(exitPrice) || 0;
    const lotSize = Number(strategy.lotSize) || 65;
    const pnl = leg.side === 'SELL'
      ? (entry - exit) * qty * lotSize
      : (exit - entry) * qty * lotSize;
    const closedLeg = {
      legId: leg.id, side: leg.side, optionType: leg.optionType, strike: leg.strike,
      expiry: resolveLegExpiry(leg, strategy),
      quantity: qty, entryPremium: entry, exitPremium: exit, pnl,
      closedAt: eventTimestamp,
    };
    const remainingLegs = strategy.legs.filter((l) => l.id !== legId);
    const transaction = {
      type: 'CLOSE',
      description: `Closed ${leg.side} ${qty}L ${leg.optionType} ${leg.strike} ${formatExpiryDisplay(resolveLegExpiry(leg, strategy))} @ ${exit.toFixed(2)} → P/L ${pnl >= 0 ? '+' : ''}${pnl.toFixed(2)}`,
      amount: pnl,
      timestamp: eventTimestamp,
    };
    try {
      const payload = {
        ...strategy,
        legs: remainingLegs,
        closedLegs: [...(strategy.closedLegs || []), closedLeg],
        transactions: [...(strategy.transactions || []), transaction],
      };
      if (!remainingLegs.length) {
        payload.status = 'closed';
        if (learning) payload.learning = learning;
      }
      const response = await fetch('/api/options-strategies', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      const enriched = await enrichStrategies(data.strategies || []);
      setSavedStrategies(enriched);
      setClosingLegInfo(null);
      setClosePrice('');
    } catch (e) { alert(e.message); }
  };

  const requestLegClose = (strategy, leg, exitPrice) => {
    const actionTimestamp = getActionTimestamp(strategy.id);
    const remainingLegs = (strategy.legs || []).filter((entry) => entry.id !== leg.id);
    if (!remainingLegs.length) {
      openLearningModal(strategy.id, actionTimestamp, { legId: leg.id, exitPrice });
      return;
    }
    closeLeg(strategy.id, leg.id, exitPrice, actionTimestamp);
  };

  const openLegEditor = (strategy, leg = null) => {
    setClosingLegInfo(null);
    setClosePrice('');
    setLegEditor(buildLegEditorDraft(strategy, leg));
  };

  const updateLegEditor = (strategy, patch) => {
    setLegEditor((current) => {
      if (!current || current.strategyId !== strategy.id) return current;

      let next = { ...current, ...patch };

      if (patch.optionType != null) {
        const options = getLegCatalogOptions(strategy, patch.optionType);
        if (!options.some((entry) => String(entry.strike) === String(next.strike))) {
          next.strike = options[0] ? String(options[0].strike) : '';
        }
      }

      if (patch.optionType != null || patch.strike != null || patch.expiry != null) {
        const directPremium = resolveChainPremium(strategy?.liveChainMap || { CE: {}, PE: {}, byExpiry: {} }, {
          optionType: next.optionType,
          strike: Number(next.strike),
          expiry: Number(next.expiry),
        });
        const selectedOption = getLegCatalogOption(strategy, next.optionType, next.strike, next.expiry);
        const selectedPremium = directPremium != null ? directPremium : (selectedOption?.premium ?? null);
        next.marketPremium = selectedPremium != null ? String(selectedPremium.toFixed(2)) : '';
        next.premium = selectedPremium != null ? String(selectedPremium.toFixed(2)) : next.premium;
      }

      return next;
    });
  };

  const saveLegEditor = async (strategyId) => {
    const strategy = savedStrategies.find((s) => s.id === strategyId);
    if (!strategy || !legEditor || legEditor.strategyId !== strategyId) return;

    const strike = Number(legEditor.strike);
    const expiry = Number(legEditor.expiry || strategy.selectedExpiry || 0);
    const premium = Number(legEditor.premium);
    const quantity = Math.max(1, parseInt(legEditor.quantity || 1, 10) || 1);
    if (!strike || !premium) { alert('Pick a strike and valid premium'); return; }

    const selectedOption = getLegCatalogOption(strategy, legEditor.optionType, strike, expiry);
    const marketPremium = selectedOption?.premium != null ? selectedOption.premium : premium;
    const existingLeg = legEditor.legId != null ? (strategy.legs || []).find((leg) => Number(leg.id) === Number(legEditor.legId)) : null;
    const maxId = Math.max(0, ...(strategy.legs || []).map((leg) => Number(leg.id) || 0));
    const nextLeg = {
      id: existingLeg?.id ?? (maxId + 1),
      side: legEditor.side,
      optionType: legEditor.optionType,
      expiry: Number.isFinite(expiry) && expiry > 0 ? expiry : null,
      strike,
      premium: normalizePremium(premium),
      marketPremium: normalizePremium(marketPremium),
      quantity,
      locked: existingLeg?.locked ?? false,
    };

    const updatedLegs = existingLeg
      ? (strategy.legs || []).map((leg) => (Number(leg.id) === Number(existingLeg.id) ? nextLeg : leg))
      : [...(strategy.legs || []), nextLeg];

    const transaction = existingLeg
      ? {
        type: 'EDIT',
        description: `Edited leg ${existingLeg.side} ${Math.max(1, parseInt(existingLeg.quantity || 1, 10) || 1)}L ${existingLeg.optionType} ${existingLeg.strike} ${formatExpiryDisplay(resolveLegExpiry(existingLeg, strategy))} → ${nextLeg.side} ${quantity}L ${nextLeg.optionType} ${strike} ${formatExpiryDisplay(resolveLegExpiry(nextLeg, strategy))} @ ${nextLeg.premium.toFixed(2)}`,
        amount: 0,
        timestamp: new Date().toISOString(),
      }
      : {
        type: 'ADD',
        description: `Added ${nextLeg.side} ${quantity}L ${nextLeg.optionType} ${strike} ${formatExpiryDisplay(resolveLegExpiry(nextLeg, strategy))} @ ${nextLeg.premium.toFixed(2)}`,
        amount: 0,
        timestamp: new Date().toISOString(),
      };

    try {
      const response = await fetch('/api/options-strategies', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...strategy,
          legs: updatedLegs,
          transactions: [...(strategy.transactions || []), transaction],
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      const enriched = await enrichStrategies(data.strategies || []);
      setSavedStrategies(enriched);
      setLegEditor(null);
    } catch (e) { alert(e.message); }
  };

  const totals = useMemo(() => {
    const totalMtm = savedStrategies.reduce((sum, strategy) => sum + Number(strategy.liveMetrics?.markToMarket || 0), 0);
    const profitable = savedStrategies.filter((strategy) => Number(strategy.liveMetrics?.markToMarket || 0) >= 0).length;
    const totalLots = savedStrategies.reduce(
      (sum, strategy) => sum + (strategy.legs || []).reduce((legSum, leg) => legSum + (Math.max(1, parseInt(leg.quantity || 1, 10) || 1)), 0),
      0,
    );
    const activeCount = savedStrategies.filter((s) => s.status === 'active').length;
    const watchingCount = savedStrategies.filter((s) => !s.status || s.status === 'watching').length;
    const closedCount = savedStrategies.filter((s) => s.status === 'closed').length;
    const activeMtm = savedStrategies.filter((s) => s.status === 'active').reduce((sum, s) => sum + Number(s.liveMetrics?.markToMarket || 0), 0);
    const totalRealizedPL = savedStrategies.reduce((sum, s) => sum + (s.closedLegs || []).reduce((cs, cl) => cs + (Number(cl.pnl) || 0), 0), 0);
    return { totalMtm, profitable, totalLots, activeCount, watchingCount, closedCount, activeMtm, totalRealizedPL };
  }, [savedStrategies]);

  const primarySummaryCards = [
    { key: 'active', label: 'Active', value: totals.activeCount, tone: theme.green },
    { key: 'watching', label: 'Watchlist', value: totals.watchingCount, tone: theme.blue },
    { key: 'liveMtm', label: 'Live MTM', value: formatCurrency(totals.totalMtm), tone: totals.totalMtm >= 0 ? theme.green : theme.red, numeric: false },
    { key: 'realized', label: 'Realized', value: formatCurrency(totals.totalRealizedPL), tone: totals.totalRealizedPL >= 0 ? theme.green : theme.red, numeric: false },
  ];

  const secondarySummaryCards = [
    { key: 'activeMtm', label: 'Active MTM', value: formatCurrency(totals.activeMtm), tone: totals.activeMtm >= 0 ? theme.green : theme.red },
    { key: 'profitable', label: 'Profitable', value: totals.profitable, tone: theme.green },
    { key: 'lots', label: 'Total Lots', value: totals.totalLots, tone: theme.purple },
    { key: 'closed', label: 'Closed', value: totals.closedCount, tone: theme.textSecondary },
  ];

  const strategyPerformanceSeries = useMemo(() => {
    if (!savedStrategies.length) return [];

    const byDate = new Map();
    savedStrategies.forEach((strategy) => {
      const realizedPL = (strategy.closedLegs || []).reduce((sum, leg) => sum + (Number(leg.pnl) || 0), 0);
      const activeMtm = Number(strategy.liveMetrics?.markToMarket || 0);
      const totalPL = realizedPL + activeMtm;

      const latestTxTime = (strategy.transactions || []).reduce((latest, tx) => {
        const nextTime = new Date(tx.timestamp || 0).getTime();
        if (Number.isNaN(nextTime)) return latest;
        return nextTime > latest ? nextTime : latest;
      }, 0);

      const fallbackTime = new Date(
        strategy.entryAt || strategy.createdAt || strategy.savedAt || strategy.updatedAt || strategy.modifiedAt || Date.now(),
      ).getTime();

      const snapshotTime = latestTxTime || (Number.isNaN(fallbackTime) ? Date.now() : fallbackTime);
      const dateKey = new Date(snapshotTime).toISOString().slice(0, 10);
      const existing = byDate.get(dateKey) || { dayPL: 0, activeMtm: 0, realizedPL: 0, strategyCount: 0 };

      byDate.set(dateKey, {
        dayPL: existing.dayPL + totalPL,
        activeMtm: existing.activeMtm + activeMtm,
        realizedPL: existing.realizedPL + realizedPL,
        strategyCount: existing.strategyCount + 1,
      });
    });

    let cumulativePL = 0;
    return Array.from(byDate.entries())
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([dateKey, values]) => {
        cumulativePL += values.dayPL;
        return {
          dateKey,
          dateLabel: formatChartDate(dateKey),
          dayPL: Number(values.dayPL.toFixed(2)),
          cumulativePL: Number(cumulativePL.toFixed(2)),
          activeMtm: Number(values.activeMtm.toFixed(2)),
          realizedPL: Number(values.realizedPL.toFixed(2)),
          strategyCount: values.strategyCount,
        };
      });
  }, [savedStrategies]);

  const latestPerformancePoint = strategyPerformanceSeries[strategyPerformanceSeries.length - 1] || null;

  const highlightedId = router.query?.saved ? String(router.query.saved) : '';

  if (!user) return <div style={styles.loading}>Loading...</div>;

  return (
    <div
      style={{
        ...styles.container,
        '--btn-primary-bg': theme.btnPrimaryBg,
        '--btn-primary-border': theme.btnPrimaryBorder,
        '--btn-primary-text': theme.btnPrimaryText,
        '--btn-secondary-bg': theme.btnSecondaryBg,
        '--btn-secondary-border': theme.btnSecondaryBorder,
        '--btn-secondary-text': theme.btnSecondaryText,
        '--input-bg': theme.inputBg,
        '--input-border': theme.inputBorder,
        '--input-text': theme.textPrimary,
      }}
      className="nifty-page-container"
    >
      <style>{`
        .mkt-pill { transition: border-color 0.15s ease, box-shadow 0.15s ease; }
        .mkt-pill:hover { border-color: ${theme.cardBorderHover} !important; }
        details[open] > .nifty-strategy-summary { border-left-color: ${theme.blue} !important; }
        details[open] > .nifty-strategy-summary .expand-chevron { transform: rotate(90deg); }
        details > .nifty-strategy-summary:hover { border-left-color: ${theme.textMuted} !important; }
        details > summary::-webkit-details-marker { display: none; }
        details > summary::marker { content: ''; }
        @media (max-width: 900px) {
          .nifty-graph-grid { grid-template-columns: 1fr !important; }
          .nifty-summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
          .nifty-metrics-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
          .nifty-analyzer-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
          .nifty-performance-kpis { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
          .nifty-leg-breakdown { flex-direction: column !important; align-items: flex-start !important; }
          .nifty-leg-prices { text-align: left !important; }
          .nifty-leg-pl { text-align: left !important; min-width: auto !important; }
          .nifty-premium-row { grid-template-columns: 1fr !important; gap: 4px !important; }
          .nifty-tx-row { flex-direction: column !important; align-items: flex-start !important; }
          .nifty-tx-amount { text-align: left !important; }
          .nifty-leg-row { flex-direction: column !important; align-items: flex-start !important; }
          .nifty-leg-toolbar { align-items: flex-start !important; }
        }
        @media (max-width: 640px) {
          .nifty-page-container { padding: 10px !important; }
          .nifty-summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; gap: 8px !important; }
          .nifty-metrics-grid { grid-template-columns: 1fr !important; }
          .nifty-performance-kpis { grid-template-columns: 1fr !important; }
          .nifty-header { flex-direction: column !important; }
          .nifty-header-actions { width: 100% !important; }
          .nifty-builder-header { flex-direction: column !important; align-items: stretch !important; }
          .nifty-builder-actions { width: 100% !important; }
          .nifty-builder-actions button { flex: 1 !important; }
          .nifty-header-actions button { flex: 1 !important; min-height: 34px !important; font-size: 11px !important; }
          .nifty-header-actions button,
          .nifty-card-actions button,
          .nifty-leg-toolbar button,
          .nifty-close-form button,
          .nifty-leg-row button {
            min-height: 36px !important;
            font-size: 11px !important;
            padding: 8px 9px !important;
            border-radius: 8px !important;
          }
          .nifty-strategy-summary { flex-direction: column !important; align-items: flex-start !important; gap: 8px !important; padding: 10px !important; }
          .nifty-strategy-title { font-size: 14px !important; }
          .nifty-strategy-body { padding: 0 10px 10px !important; }
          .nifty-card-actions { flex-direction: column !important; }
          .nifty-card-actions button { width: 100% !important; min-height: 40px !important; }
          .nifty-past-date-controls { width: 100% !important; }
          .nifty-past-date-controls input[type="datetime-local"] { width: 100% !important; }
          .nifty-analyzer-grid { grid-template-columns: 1fr !important; }
          .nifty-analyzer-header { flex-direction: column !important; align-items: flex-start !important; }
          .nifty-close-form { flex-direction: column !important; align-items: stretch !important; }
          .nifty-close-form input { width: 100% !important; }
          .nifty-close-form button { min-height: 38px !important; }
          .nifty-profit-banner { padding: 10px !important; }
          .nifty-profit-banner > div:first-child { flex-direction: column !important; gap: 8px !important; }
          .nifty-leg-editor { padding: 8px !important; }
          .nifty-leg-editor-row { flex-direction: column !important; }
          .nifty-leg-editor-row select, .nifty-leg-editor-row input { width: 100% !important; }
          .nifty-section-header { font-size: 14px !important; }
          .nifty-page-title { font-size: 20px !important; }
          .nifty-badge { font-size: 10px !important; padding: 3px 7px !important; }
          .nifty-summary-value { font-size: 17px !important; }
          .nifty-info-band { font-size: 11px !important; }
          .nifty-strategy-summary .expand-chevron { font-size: 14px !important; }
          .market-ticker { gap: 6px !important; }
          .nifty-stats-more summary { padding: 8px 10px !important; }
          .nifty-builder-body { padding: 10px !important; }
        }
        @media (max-width: 560px) {
          .nifty-learnings-ticker { display: none !important; }
          .market-ticker {
            flex-wrap: nowrap !important;
            overflow-x: auto !important;
            overscroll-behavior-x: contain !important;
            gap: 7px !important;
            margin-bottom: 12px !important;
            padding-bottom: 4px !important;
            -ms-overflow-style: none;
            scrollbar-width: none;
          }
          .market-ticker::-webkit-scrollbar { display: none; }
          .market-ticker .mkt-pill {
            flex: 0 0 156px !important;
            min-width: 156px !important;
            padding: 7px 8px !important;
            border-radius: 12px !important;
          }
          .market-ticker .mkt-pill span {
            white-space: normal !important;
          }
          .nifty-header-actions {
            width: 100% !important;
            display: grid !important;
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
            gap: 6px !important;
          }
          .nifty-header-actions button {
            width: 100% !important;
            min-height: 32px !important;
            font-size: 11px !important;
            padding: 7px 8px !important;
          }
          .nifty-header-actions .header-ghost-btn:last-child { display: none !important; }
          .nifty-page-title { font-size: 18px !important; }
          .nifty-section-header { font-size: 12px !important; gap: 6px !important; }
          .nifty-summary-value { font-size: 15px !important; }
          .nifty-builder-actions { display: grid !important; grid-template-columns: repeat(2, minmax(0, 1fr)) !important; gap: 6px !important; }
          .nifty-strategy-summary { padding: 8px !important; gap: 6px !important; }
          .nifty-strategy-body { padding: 0 8px 8px !important; }
          .nifty-header-actions button,
          .nifty-card-actions button,
          .nifty-leg-toolbar button,
          .nifty-close-form button,
          .nifty-leg-row button {
            min-height: 34px !important;
            font-size: 10px !important;
            padding: 7px 8px !important;
          }
          .nifty-valuation-bar {
            margin-bottom: 12px !important;
            padding: 9px !important;
            gap: 8px !important;
          }
          .nifty-refresh-wrap,
          .nifty-valuation-wrap {
            min-width: 0 !important;
            max-width: none !important;
            width: 100% !important;
            flex: 1 1 100% !important;
          }
          .nifty-refresh-row { grid-template-columns: 1fr !important; }
          .nifty-performance-panel { padding: 10px !important; margin-bottom: 12px !important; }
          .nifty-performance-chart { height: 190px !important; }
        }
        @media (max-width: 400px) {
          .nifty-page-container { padding: 8px !important; }
          .market-ticker .mkt-pill {
            flex-basis: 148px !important;
            min-width: 148px !important;
          }
          .nifty-summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
          .nifty-header-actions { grid-template-columns: 1fr !important; }
          .nifty-header-actions .header-ghost-btn { display: none !important; }
          .nifty-builder-actions { grid-template-columns: 1fr !important; }
          .nifty-header-actions button,
          .nifty-card-actions button,
          .nifty-leg-toolbar button,
          .nifty-close-form button,
          .nifty-leg-row button {
            min-height: 32px !important;
            font-size: 10px !important;
            padding: 6px 8px !important;
          }
          .nifty-summary-value { font-size: 14px !important; }
          .nifty-page-title { font-size: 17px !important; }
        }
        @keyframes learnings-scroll {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        @keyframes nifty-orbit-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes nifty-pulse-dot {
          0%, 100% { transform: scale(0.8); opacity: 0.55; }
          50% { transform: scale(1.2); opacity: 1; }
        }
      `}</style>

      {/* ── Learnings Ticker ── */}
      {(() => {
        const allLearnings = savedStrategies.filter((s) => s.learning).map((s) => ({
          id: s.id, name: s.name || 'Strategy', learning: s.learning,
        }));
        if (!allLearnings.length) return null;
        const items = [...allLearnings, ...allLearnings]; // duplicate for seamless loop
        return (
          <div style={styles.learningsTicker} className="nifty-learnings-ticker">
            <span style={styles.learningsTickerLabel}>💡 Lessons</span>
            <div style={styles.learningsTickerTrack}>
              <div className="learnings-scroll-inner" style={styles.learningsScrollInner}>
                {items.map((item, i) => (
                  <span key={`${item.id}-${i}`} style={styles.learningsTickerItem}>
                    <span style={styles.learningsTickerName}>{item.name}:</span>
                    &nbsp;{item.learning}
                    <span style={styles.learningsTickerSep}>•</span>
                  </span>
                ))}
              </div>
            </div>
            <style>{`
              .learnings-scroll-inner {
                animation: learnings-scroll 40s linear infinite;
              }
              .learnings-scroll-inner:hover {
                animation-play-state: paused;
              }
            `}</style>
          </div>
        );
      })()}

      {/* ── Global Market Ticker ── */}
      {marketIndices.length > 0 && (
        <div style={styles.tickerStrip} className="market-ticker">
          {loadingIndices ? <InlineLoaderChip text="Refreshing market feed" /> : null}
          {marketIndices.map((idx) => {
            const up = idx.change >= 0;
            const palette = getTickerAppearance(idx.key, theme);
            return (
              <div
                key={idx.key}
                className="mkt-pill"
                style={{
                  ...styles.tickerPill,
                  borderColor: palette.border,
                  background: palette.background,
                  boxShadow: `inset 0 1px 0 rgba(255,255,255,0.04), 0 10px 24px ${palette.glow}`,
                }}
              >
                <div style={styles.tickerBody}>
                  <div style={styles.tickerTopRow}>
                    <span style={{ ...styles.tickerName, color: palette.accent }}>{idx.name}</span>
                    <span style={{ ...styles.tickerWindow, color: up ? theme.green : theme.red }}>
                      {up ? '+' : '-'}{Math.abs(Number(idx.change) || 0).toFixed(idx.key === 'INDIAVIX' ? 2 : 0)} pts
                    </span>
                  </div>
                  <div style={styles.tickerBottomRow}>
                    <div style={styles.tickerPriceBlock}>
                      <span style={{ ...styles.tickerPrice, color: palette.price }}>
                        {Number(idx.price).toLocaleString('en-IN', { maximumFractionDigits: idx.key === 'INDIAVIX' ? 2 : 0 })}
                      </span>
                      <span style={styles.tickerWindowSubtle}>
                        {idx.changeWindow || '1D'} trend
                      </span>
                    </div>
                    <span style={{ ...styles.tickerDelta, color: up ? theme.green : theme.red }}>
                      {up ? '▲' : '▼'} {Math.abs(idx.changePercent).toFixed(2)}%
                    </span>
                  </div>
                  <div style={styles.tickerTrendRow}>
                    <TinyTrendSparkline history={idx.history} color={up ? theme.green : theme.red} styles={styles} />
                  </div>
                  {idx.warning ? (
                    <div style={styles.tickerWarningLine} title={idx.warning}>
                      {idx.warning}
                    </div>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div style={styles.header} className="nifty-header">
        <div>
          <h1 style={styles.title} className="nifty-page-title">📊 Nifty Strategy Tracker</h1>
          <p style={styles.subtitle}>Saved strategies with live P/L, analyzer, and transaction tracking.</p>
        </div>
        <div style={styles.headerActions} className="nifty-header-actions">
          <button onClick={() => loadSavedStrategies({ showSpinner: false, includeWhatIf: true, refreshIndices: true })} style={styles.secondaryButton}>{refreshing ? 'Refreshing...' : 'Refresh'}</button>
          <button
            type="button"
            onClick={() => openEmbeddedBuilder(null)}
            style={styles.primaryButton}
          >{showEmbeddedBuilder ? 'Builder Open' : 'Create Strategy'}</button>
          <button className="header-ghost-btn" onClick={() => router.push('/strategy-history')} style={styles.ghostButton}>History</button>
          <button className="header-ghost-btn" onClick={() => router.push('/dashboard')} style={styles.ghostButton}>Dashboard</button>
        </div>
      </div>

      <details
        style={{
          ...styles.valuationBar,
          borderColor: theme.cardBorder,
          borderLeftColor: theme.blue,
          background: theme.cardBgGradient,
          boxShadow: `0 10px 22px ${theme.shadow}`,
        }}
        className="nifty-valuation-bar"
      >
        <summary style={styles.refreshSummaryRow}>
          <div>
            <div style={styles.valuationTitle}>Refresh & MTM</div>
            <div style={styles.refreshSummaryText}>{autoRefreshEnabled ? `${refreshIntervalSeconds || 'Manual'}s · ${refreshSession}` : 'Manual refresh'} · {getPricingSourceLabel(currentValuationSource)}</div>
          </div>
          <div style={styles.refreshSummaryMeta}>
            <span style={styles.refreshMetaBadge}>{lastRefreshAt ? `Last ${new Date(lastRefreshAt).toLocaleTimeString()}` : 'Not refreshed yet'}</span>
            <span style={styles.refreshSummaryCaret}>▾</span>
          </div>
        </summary>
        <div style={styles.refreshPanelBody}>
          <div style={styles.refreshControlWrap} className="nifty-refresh-wrap">
            <div style={styles.refreshControlRow} className="nifty-refresh-row">
              <label style={styles.refreshToggleLabel}>
                <input
                  type="checkbox"
                  checked={autoRefreshEnabled}
                  onChange={(e) => setAutoRefreshEnabled(e.target.checked)}
                />
                Auto refresh
              </label>
              <select
                value={refreshIntervalSeconds}
                onChange={(e) => setRefreshIntervalSeconds(Number(e.target.value) || 0)}
                style={styles.valuationSelect}
              >
                {REFRESH_INTERVAL_OPTIONS.map((option) => (
                  <option key={`refresh-${option.value}`} value={option.value}>{option.label}</option>
                ))}
              </select>
            </div>
            <select
              value={refreshSession}
              onChange={(e) => setRefreshSession(e.target.value)}
              style={styles.valuationSelect}
            >
              {MARKET_SESSION_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
            <div style={styles.refreshStatusText}>{refreshStatusLabel}</div>
          </div>
          <div style={styles.valuationControlWrap} className="nifty-valuation-wrap">
            <label htmlFor="current-valuation-source" style={{ ...styles.valuationLabel, color: theme.textHeading }}>MTM valuation method</label>
            <select
              id="current-valuation-source"
              value={currentValuationSource}
              onChange={(e) => setCurrentValuationSource(e.target.value)}
              style={{
                ...styles.valuationSelect,
                borderColor: theme.inputBorder,
                background: theme.inputBg,
                color: theme.textPrimary,
              }}
            >
              {CURRENT_VALUATION_OPTIONS.map((option) => (
                <option key={option} value={option}>{getPricingSourceLabel(option)}</option>
              ))}
            </select>
          </div>
        </div>
      </details>

      {strategyPerformanceSeries.length > 0 ? (
        <div
          style={{
            ...styles.performancePanel,
            borderColor: theme.cardBorder,
            background: theme.panelBg,
            boxShadow: `0 10px 26px ${theme.shadow}`,
          }}
          className="nifty-performance-panel"
        >
          <div style={styles.performanceHeader}>
            <div>
              <div style={{ ...styles.performanceTitle, color: theme.textHeading }}>Strategy P/L Timeline</div>
              <div style={{ ...styles.performanceSubtitle, color: theme.textSecondary }}>Daily snapshot of realized + active MTM, grouped by date.</div>
            </div>
            <div style={{ ...styles.performanceDatePill, borderColor: theme.cardBorderHover, color: theme.textPrimary, background: theme.badgeBg }}>
              {latestPerformancePoint ? `Latest: ${latestPerformancePoint.dateLabel}` : 'Latest: -'}
            </div>
          </div>

          <div style={styles.performanceKpiGrid} className="nifty-performance-kpis">
            <div style={{ ...styles.performanceKpiCard, borderColor: theme.cardBorder }}>
              <div style={{ ...styles.performanceKpiLabel, color: theme.textSecondary }}>Cumulative P/L</div>
              <div style={{ ...styles.performanceKpiValue, color: (latestPerformancePoint?.cumulativePL || 0) >= 0 ? theme.green : theme.red }}>
                {formatCurrency(latestPerformancePoint?.cumulativePL || 0)}
              </div>
            </div>
            <div style={{ ...styles.performanceKpiCard, borderColor: theme.cardBorder }}>
              <div style={{ ...styles.performanceKpiLabel, color: theme.textSecondary }}>Day Snapshot</div>
              <div style={{ ...styles.performanceKpiValue, color: (latestPerformancePoint?.dayPL || 0) >= 0 ? theme.green : theme.red }}>
                {formatCurrency(latestPerformancePoint?.dayPL || 0)}
              </div>
            </div>
            <div style={{ ...styles.performanceKpiCard, borderColor: theme.cardBorder }}>
              <div style={{ ...styles.performanceKpiLabel, color: theme.textSecondary }}>Strategies Counted</div>
              <div style={{ ...styles.performanceKpiValue, color: theme.textPrimary }}>
                {latestPerformancePoint?.strategyCount || 0}
              </div>
            </div>
          </div>

          <div style={styles.performanceChartWrap} className="nifty-performance-chart">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart
                data={strategyPerformanceSeries}
                margin={{ top: 8, right: 10, left: -8, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="timelineCumulativeFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={theme.blue} stopOpacity={0.35} />
                    <stop offset="95%" stopColor={theme.blue} stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={theme.graphGridLine} strokeDasharray="3 3" />
                <XAxis
                  dataKey="dateLabel"
                  tick={{ fill: theme.textSecondary, fontSize: 12 }}
                  axisLine={{ stroke: theme.divider }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: theme.textSecondary, fontSize: 12 }}
                  axisLine={{ stroke: theme.divider }}
                  tickLine={false}
                  tickFormatter={(value) => formatCurrency(value)}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: 10,
                    border: `1px solid ${theme.cardBorder}`,
                    background: theme.cardBg,
                    color: theme.textPrimary,
                    fontSize: 12,
                  }}
                  formatter={(value, key) => {
                    if (key === 'dayPL') return [formatCurrency(Number(value) || 0), 'Day P/L'];
                    if (key === 'cumulativePL') return [formatCurrency(Number(value) || 0), 'Cumulative P/L'];
                    return [String(value), String(key)];
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="cumulativePL"
                  stroke={theme.blue}
                  strokeWidth={2}
                  fill="url(#timelineCumulativeFill)"
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="dayPL"
                  stroke={theme.green}
                  strokeWidth={2}
                  dot={{ r: 2, fill: theme.green }}
                  activeDot={{ r: 5 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      ) : null}

      <div style={styles.summaryGrid} className="nifty-summary-grid">
        {primarySummaryCards.map((card) => (
          <div key={card.key} style={{ ...styles.summaryCard, borderTopColor: card.tone }}>
            <div style={{ ...styles.summaryLabel, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
              {card.label}
              {card.key === 'active' && loadingStrategies ? <InlineLoaderChip text="Syncing" /> : null}
            </div>
            <div style={{ ...styles.summaryValue, color: card.tone }} className="nifty-summary-value">{card.value}</div>
          </div>
        ))}
      </div>

      <details
        style={{
          ...styles.summaryDetails,
          background: theme.panelBg,
          border: `1px solid ${theme.cardBorder}`,
          borderRadius: '14px',
          padding: '8px',
        }}
        className="nifty-stats-more"
      >
        <summary
          style={{
            ...styles.summaryDetailsSummary,
            background: theme.cardBgGradient,
            borderColor: theme.cardBorder,
            color: theme.textPrimary,
          }}
        >
          More stats
        </summary>
        <div style={styles.summaryGridSecondary}>
          {secondarySummaryCards.map((card) => (
            <div key={card.key} style={{ ...styles.summaryCard, borderTopColor: card.tone }}>
              <div style={styles.summaryLabel}>{card.label}</div>
              <div style={{ ...styles.summaryValue, color: card.tone }}>{card.value}</div>
            </div>
          ))}
        </div>
      </details>

      <section
        style={{
          ...styles.builderSection,
          borderColor: theme.cardBorder,
          background: theme.panelBg,
          boxShadow: `0 10px 24px ${theme.shadow}`,
        }}
      >
        <div
          style={{
            ...styles.builderSectionHeader,
            borderBottomColor: theme.cardBorder,
            background: theme.cardBgGradient,
          }}
          className="nifty-builder-header"
        >
          <div>
            <div style={{ ...styles.builderSectionTitle, color: theme.textHeading }}>Strategy Builder + Optimizer</div>
            <div style={{ ...styles.builderSectionHint, color: theme.textSecondary }}>Create, edit, graph, and optimize strategies on this page. The builder loads only when you open it.</div>
          </div>
          <div style={styles.builderSectionActions} className="nifty-builder-actions">
            <button type="button" onClick={() => openEmbeddedBuilder(null)} style={styles.primaryButton}>New draft</button>
            {embeddedBuilderLoaded ? (
              <button type="button" onClick={() => setShowEmbeddedBuilder((current) => !current)} style={styles.secondaryButton}>
                {showEmbeddedBuilder ? 'Hide builder' : 'Show builder'}
              </button>
            ) : null}
          </div>
        </div>
        {embeddedBuilderLoaded && showEmbeddedBuilder ? (
          <div
            style={{
              ...styles.builderSectionBody,
              background: theme.pageBgSolid,
            }}
            className="nifty-builder-body"
          >
            <EmbeddedOptionsStrategyPage
              key={`${embeddedBuilderStrategyId || 'new'}-${embeddedBuilderVersion}`}
              embedded
              hideBackButton
              strategyIdParam={embeddedBuilderStrategyId}
              onStrategySaved={() => {
                loadSavedStrategies({ showSpinner: false, includeWhatIf: true, refreshIndices: true });
              }}
              onOpenTracker={() => {
                setShowEmbeddedBuilder(false);
                setEmbeddedBuilderStrategyId(null);
              }}
            />
          </div>
        ) : null}
      </section>

      {loading ? <OrbitalLoader label="Loading saved strategies..." /> : null}
      {!loading && error ? <div style={styles.errorText}>{error}</div> : null}
      {!loading && !error && savedStrategies.length === 0 ? (
        <div style={styles.emptyState}>No Nifty options strategy has been saved yet. Open Nifty Options, add legs, and click save.</div>
      ) : null}

      {(() => {
        const activeStrategies = savedStrategies.filter((s) => s.status === 'active');
        const watchingStrategies = savedStrategies.filter((s) => !s.status || s.status === 'watching');
        const closedStrategies = savedStrategies.filter((s) => s.status === 'closed');

        const renderCard = (strategy, defaultOpen) => {
          const metrics = strategy.liveMetrics || computeStrategyMetrics(strategy.legs || [], Number(strategy.lotSize) || 65, Number(strategy.savedAtSpot) || 0);
          const spotMove = Number((Number(strategy.currentSpot || 0) - Number(strategy.savedAtSpot || 0)).toFixed(2));
          const spotMovePct = Number(strategy.savedAtSpot)
            ? Number(((spotMove / Number(strategy.savedAtSpot)) * 100).toFixed(2))
            : 0;
          const isActive = strategy.status === 'active';
          const isClosed = strategy.status === 'closed';
          const statusLabel = isActive ? '✅ BOUGHT' : isClosed ? '🔒 CLOSED' : '👁 WATCHING';
          const statusColor = isActive ? theme.green : isClosed ? theme.textSecondary : theme.blue;
          const isPastDateEnabled = Boolean(usePastActionDate[strategy.id]);
          const actionDateTime = actionDateTimeByStrategy[strategy.id] || '';

          return (
            <details key={strategy.id} style={{ ...styles.strategyPanel, borderColor: isActive ? theme.greenDim : theme.cardBorder }} open={highlightedId === String(strategy.id) || defaultOpen}>
              <summary style={styles.strategySummary} className="nifty-strategy-summary">
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, minWidth: 0 }}>
                  <span className="expand-chevron" style={{ fontSize: '18px', color: theme.textMuted, transition: 'transform 0.2s', flexShrink: 0 }}>▶</span>
                  <div style={{ minWidth: 0 }}>
                    <div style={styles.strategyTitle} className="nifty-strategy-title">
                      {strategy.name}
                      <span style={{ ...styles.statusBadge, color: statusColor, borderColor: statusColor }}>{statusLabel}</span>
                    </div>
                    <div style={styles.strategyMeta}>
                      {strategy.expiryLabel || 'No expiry'} · {(strategy.legs || []).length} open legs{(strategy.closedLegs || []).length > 0 ? ` · ${strategy.closedLegs.length} closed` : ''} · built with {getPricingSourceLabel(strategy.strategyPricingSource || strategy.pricingSource || 'blend')}
                    </div>
                    {!isClosed && (
                      <div style={{ fontSize: '11px', color: theme.textMuted, marginTop: '4px' }}>
                        Current valuation: {getPricingSourceLabel(strategy.currentValuationSource || currentValuationSource)} · {strategy.liveSource || 'saved'}
                      </div>
                    )}
                  </div>
                </div>
                <div style={styles.summaryBadges}>
                  {isClosed ? (() => {
                    const closedSummary = summarizeClosedStrategy(strategy);
                    return (
                      <>
                        <span className="nifty-badge" style={{ ...styles.badge, color: closedSummary.realizedPL >= 0 ? theme.green : theme.red, borderColor: closedSummary.realizedPL >= 0 ? theme.greenDim : theme.redDim }}>
                          P/L {formatCurrency(closedSummary.realizedPL)}
                        </span>
                        {closedSummary.transactionCost > 0 && (
                          <span className="nifty-badge" style={{ ...styles.badge, color: theme.textMuted, borderColor: theme.cardBorder }}>
                            Tax {formatCurrency(closedSummary.transactionCost)}
                          </span>
                        )}
                      </>
                    );
                  })() : (
                    <>
                      <span className="nifty-badge" style={{ ...styles.badge, color: metrics.markToMarket >= 0 ? theme.green : theme.red, borderColor: metrics.markToMarket >= 0 ? theme.greenDim : theme.redDim }}>
                        MTM {formatCurrency(metrics.markToMarket)}
                      </span>
                      <span className="nifty-badge" style={{ ...styles.badge, color: spotMove >= 0 ? theme.green : theme.red, borderColor: theme.cardBorderHover }}>
                        {spotMove >= 0 ? '▲' : '▼'} {formatCurrency(Math.abs(spotMove))}
                      </span>
                    </>
                  )}
                </div>
              </summary>

              <div style={styles.strategyBody} className="nifty-strategy-body">
                {isClosed && <ClosedStrategyPanel strategy={strategy} styles={styles} theme={theme} />}

                {!isClosed && (
                  <>
                {/* ── Prominent P/L Banner ── */}
                {isActive && (() => {
                  const analysis = analyzeStrategy(strategy, metrics);
                  return (
                    <div style={{ ...styles.profitBanner, borderColor: analysis.totalPL >= 0 ? theme.greenDim : theme.redDim, background: analysis.totalPL >= 0 ? `${theme.green}14` : `${theme.red}14` }} className="nifty-profit-banner">
                      <div style={styles.profitBannerRow}>
                        <div>
                          <div style={styles.profitBannerLabel}>Current Total P/L</div>
                          <div style={{ ...styles.profitBannerValue, color: analysis.totalPL >= 0 ? theme.green : theme.red }}>
                            {analysis.totalPL >= 0 ? '+' : ''}{formatCurrency(analysis.totalPL)}
                          </div>
                        </div>
                        <div style={styles.profitBannerSplit}>
                          <div><span style={styles.profitBannerSmLabel}>Unrealized:</span> <span style={{ color: analysis.unrealizedPL >= 0 ? theme.green : theme.red, fontWeight: 'bold' }}>{formatCurrency(analysis.unrealizedPL)}</span></div>
                          <div><span style={styles.profitBannerSmLabel}>Realized:</span> <span style={{ color: analysis.realizedPL >= 0 ? theme.green : theme.red, fontWeight: 'bold' }}>{formatCurrency(analysis.realizedPL)}</span></div>
                          <div><span style={styles.profitBannerSmLabel}>Premium Left:</span> <span style={{ color: theme.textPrimary, fontWeight: 'bold' }}>{formatCurrency(analysis.premiumLeft)} ({(analysis.premiumLeft / (Number(strategy.lotSize) || 65)).toFixed(2)} pts)</span></div>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {(isActive || isClosed) && (
                  <StrategyAnalyzer strategy={strategy} metrics={metrics} styles={styles} theme={theme} />
                )}

                <div style={styles.metricsGrid} className="nifty-metrics-grid">
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Entry Spot</div><div style={styles.metricValue}>{formatCurrency(strategy.savedAtSpot)}</div></div>
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Live Spot</div><div style={styles.metricValue}>{formatCurrency(strategy.currentSpot)}</div></div>
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Spot Move</div><div style={{ ...styles.metricValue, color: spotMove >= 0 ? theme.green : theme.red }}>{spotMove >= 0 ? '▲' : '▼'} {formatCurrency(Math.abs(spotMove))}</div><div style={styles.metricSub}>{spotMove >= 0 ? '+' : ''}{spotMovePct}% since save</div></div>
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Live MTM</div><div style={{ ...styles.metricValue, color: metrics.markToMarket >= 0 ? theme.green : theme.red }}>{formatCurrency(metrics.markToMarket)}</div></div>
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Current Payoff</div><div style={{ ...styles.metricValue, color: metrics.currentPayoff >= 0 ? theme.green : theme.red }}>{formatCurrency(metrics.currentPayoff)}</div></div>
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Max Profit</div><div style={{ ...styles.metricValue, color: theme.green }}>{formatCurrency(metrics.maxProfit)}</div></div>
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Max Loss</div><div style={{ ...styles.metricValue, color: theme.red }}>{formatCurrency(Math.abs(metrics.maxLoss))}</div></div>
                  <div style={styles.metricBox}><div style={styles.metricLabel}>Lots / Lot Size</div><div style={styles.metricValue}>{(strategy.legs || []).reduce((sum, leg) => sum + (Math.max(1, parseInt(leg.quantity || 1, 10) || 1)), 0)} × {Number(strategy.lotSize) || 65}</div></div>
                </div>

                <div style={styles.infoBand} className="nifty-info-band">
                  <div><strong>Profit Range:</strong> {metrics.profitRange}</div>
                  <div><strong>Loss Range:</strong> {metrics.lossRange}</div>
                  <div><strong>Break-even:</strong> {metrics.breakEvens.length ? metrics.breakEvens.join(', ') : '—'}</div>
                </div>

                <details style={styles.innerExpand} open>
                  <summary style={styles.expandTitle}>Expand graphs</summary>
                  <div style={styles.graphGrid} className="nifty-graph-grid">
                    <div style={styles.graphCard}>
                      <div style={styles.graphTitle}>1. Payoff Curve with X/Y range</div>
                      <AxisPayoffChart points={metrics.points} minY={metrics.minY} maxY={metrics.maxY} currentSpot={strategy.currentSpot} theme={theme} styles={styles} />
                      <div style={styles.graphHint}>Hover over the curve points to see spot and P/L.</div>
                    </div>
                    <div style={styles.graphCard}>
                      <div style={styles.graphTitle}>2. What-If Portfolio Value</div>
                      <ScenarioBarChart scenarios={strategy.whatIfScenarios?.length ? strategy.whatIfScenarios : metrics.scenarios} styles={styles} theme={theme} />
                      <div style={styles.graphHint}>
                        Shows projected portfolio MTM around live spot {Math.round(strategy.currentSpot || strategy.whatIfBaseSpot || 0).toLocaleString('en-IN')}, with the exact current spot highlighted plus 50-point downside and upside scenarios.
                      </div>
                      <WhatIfScenarioGrid scenarios={strategy.whatIfScenarios || []} styles={styles} theme={theme} />
                    </div>
                    <div style={styles.graphCard}>
                      <div style={styles.graphTitle}>3. Profit / Loss Range Map</div>
                      <RangeBandChart metrics={metrics} currentSpot={strategy.currentSpot} styles={styles} />
                      <div style={styles.graphHint}>Green is the profit band, red is the loss band, blue is the live spot.</div>
                    </div>
                    <div style={styles.graphCard}>
                      <div style={styles.graphTitle}>4. Premium Breakdown</div>
                      <PremiumBars metrics={metrics} styles={styles} theme={theme} />
                      <div style={styles.graphHint}>Hover the bars for entry, close, captured, and live MTM values.</div>
                    </div>
                  </div>
                </details>

                <details style={styles.legsPanel}>
                  <summary style={{ ...styles.graphTitle, cursor: 'pointer', userSelect: 'none' }}>Open Legs ({(strategy.legs || []).length}) — click to expand</summary>
                  <div style={styles.legsToolbar} className="nifty-leg-toolbar">
                    <div style={styles.legsToolbarText}>Compact rows with quick add, edit, and close actions.</div>
                    {isActive && (
                      <button onClick={() => openLegEditor(strategy)} style={styles.addLegInlineBtn}>+ Quick Add Leg</button>
                    )}
                  </div>
                  {legEditor?.strategyId === strategy.id && legEditor.legId == null && (
                    <LegEditor
                      draft={legEditor}
                      strategy={strategy}
                      styles={styles}
                      theme={theme}
                      title="Add New Leg"
                      onFieldChange={(patch) => updateLegEditor(strategy, patch)}
                      onSave={() => saveLegEditor(strategy.id)}
                      onCancel={() => setLegEditor(null)}
                    />
                  )}
                  <div style={styles.legsWrap}>
                    {(strategy.legs || []).map((leg) => {
                      const isClosing = closingLegInfo?.strategyId === strategy.id && closingLegInfo?.legId === leg.id;
                      const isEditing = legEditor?.strategyId === strategy.id && Number(legEditor?.legId) === Number(leg.id);
                      const legExpiry = resolveLegExpiry(leg, strategy);
                      const expiryTone = getExpiryBadgeTone(legExpiry);
                      const qty = Math.max(1, parseInt(leg.quantity || 1, 10) || 1);
                      const entryP = Number(leg.premium) || 0;
                      const currentP = Number(leg.marketPremium ?? leg.premium) || 0;
                      const lotSz = Number(strategy.lotSize) || 65;
                      const legPL = leg.side === 'SELL' ? (entryP - currentP) * qty * lotSz : (currentP - entryP) * qty * lotSz;
                      const closeAction = leg.side === 'BUY' ? 'Sell at' : 'Buy back at';
                      return (
                        <div key={`${strategy.id}-${leg.id}-${leg.strike}`} style={styles.legCardWrap}>
                          <div style={styles.legCard}>
                            <div style={styles.legCardHeader} className="nifty-leg-row">
                              <div style={styles.legRowMain}>
                                <span style={{ ...styles.legSideBadge, background: leg.side === 'BUY' ? `${theme.blue}20` : `${theme.red}20`, color: leg.side === 'BUY' ? theme.blue : theme.red }}>{leg.side}</span>
                                <span style={styles.legCardStrike}>{qty}L {leg.optionType} {leg.strike}</span>
                                <span style={{ ...styles.legExpiryBadge, background: expiryTone.background, color: expiryTone.color, borderColor: expiryTone.border }}>{formatExpiryDisplay(legExpiry)}</span>
                                <span style={styles.legCardPrices}>Entry {entryP.toFixed(2)} · Live {currentP.toFixed(2)}</span>
                              </div>
                              <div style={styles.legRowActions}>
                                <span style={{ ...styles.legCardPL, color: legPL >= 0 ? theme.green : theme.red }}>{legPL >= 0 ? '+' : ''}{formatCurrency(legPL)}</span>
                                {isActive && !isClosing && (
                                  <button
                                    onClick={(e) => { e.stopPropagation(); openLegEditor(strategy, leg); }}
                                    style={styles.legSmallActionBtn}
                                  >Edit</button>
                                )}
                                {isActive && !isClosing && (
                                  <button
                                    onClick={(e) => { e.stopPropagation(); setLegEditor(null); setClosingLegInfo({ strategyId: strategy.id, legId: leg.id }); setClosePrice(String(currentP.toFixed(2))); }}
                                    style={styles.closeLegInlineBtn}
                                  >{closeAction}</button>
                                )}
                              </div>
                            </div>
                          </div>
                          {isEditing && (
                            <LegEditor
                              draft={legEditor}
                              strategy={strategy}
                              styles={styles}
                              theme={theme}
                              title={`Edit ${leg.optionType} ${leg.strike} (${formatExpiryDisplay(resolveLegExpiry(leg, strategy))})`}
                              onFieldChange={(patch) => updateLegEditor(strategy, patch)}
                              onSave={() => saveLegEditor(strategy.id)}
                              onCancel={() => setLegEditor(null)}
                            />
                          )}
                          {isClosing && (
                            <div style={styles.closeLegForm} className="nifty-close-form">
                              <div style={styles.closeLegFormHeader}>{closeAction} — {leg.optionType} {leg.strike} ({formatExpiryDisplay(resolveLegExpiry(leg, strategy))})</div>
                              <div style={styles.closeLegFormRow}>
                                <label style={styles.closeLegLabel}>{closeAction}:</label>
                                <input
                                  type="number"
                                  step="0.05"
                                  value={closePrice}
                                  onChange={(e) => setClosePrice(e.target.value)}
                                  style={styles.closeLegInput}
                                  placeholder={`${closeAction} price`}
                                  autoFocus
                                />
                              </div>
                              {closePrice && (() => {
                                const exitP = Number(closePrice) || 0;
                                const previewPL = leg.side === 'SELL' ? (entryP - exitP) * qty * lotSz : (exitP - entryP) * qty * lotSz;
                                return (
                                  <div style={{ ...styles.closeLegPreview, color: previewPL >= 0 ? theme.green : theme.red }}>
                                    P/L: {previewPL >= 0 ? '+' : ''}{formatCurrency(previewPL)}
                                  </div>
                                );
                              })()}
                              <div style={styles.closeLegFormBtns}>
                                <button onClick={() => requestLegClose(strategy, leg, closePrice)} style={styles.closeLegConfirm}>✅ Confirm Close</button>
                                <button onClick={() => { setClosingLegInfo(null); setClosePrice(''); }} style={styles.closeLegCancel}>Cancel</button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  {(strategy.legs || []).length === 0 && <div style={{ color: theme.textMuted, fontSize: 12, marginTop: 6 }}>All legs closed</div>}
                </details>
                  </>
                )}

                <div style={styles.cardActions} className="nifty-card-actions">
                  <div style={styles.pastDateControls} className="nifty-past-date-controls">
                    <label style={styles.pastDateToggleLabel}>
                      <input
                        type="checkbox"
                        checked={isPastDateEnabled}
                        onChange={(e) => togglePastActionDate(strategy.id, e.target.checked)}
                      />
                      Past date entry
                    </label>
                    {isPastDateEnabled ? (
                      <input
                        type="datetime-local"
                        value={actionDateTime}
                        onChange={(e) => setActionDateTimeByStrategy((current) => ({ ...current, [strategy.id]: e.target.value }))}
                        style={styles.pastDateInput}
                        title="Select action date/time for bought and close"
                      />
                    ) : null}
                  </div>
                  {(!strategy.status || strategy.status === 'watching') && (
                    <button onClick={() => updateStrategyStatus(strategy.id, 'active', getActionTimestamp(strategy.id))} style={styles.buyButton}>✅ Mark as Bought</button>
                  )}
                  {isActive && (strategy.legs || []).length > 0 && (
                    <button onClick={() => openLearningModal(strategy.id, getActionTimestamp(strategy.id))} style={styles.closeStratBtn}>🔒 Close Strategy</button>
                  )}
                  {isClosed && (
                    <button onClick={() => updateStrategyStatus(strategy.id, 'watching')} style={styles.secondaryButton}>↩ Move to Watchlist</button>
                  )}
                  <button onClick={() => openEmbeddedBuilder(String(strategy.id))} style={styles.primaryButton}>Edit In Builder</button>
                  <button onClick={() => deleteSavedStrategy(strategy.id)} style={styles.deleteButton}>Delete</button>
                </div>
              </div>
            </details>
          );
        };

        return (
          <>
            {activeStrategies.length > 0 && (
              <>
                <div style={styles.sectionHeader} className="nifty-section-header">
                  <span style={styles.sectionIcon}>✅</span>
                  <span>Active Positions ({activeStrategies.length})</span>
                </div>
                <div style={styles.strategyStack}>
                  {activeStrategies.map((s) => renderCard(s, false))}
                </div>
              </>
            )}

            {watchingStrategies.length > 0 && (
              <>
                <div style={styles.sectionHeader} className="nifty-section-header">
                  <span style={styles.sectionIcon}>👁</span>
                  <span>Watchlist ({watchingStrategies.length})</span>
                </div>
                <div style={styles.strategyStack}>
                  {watchingStrategies.map((s) => renderCard(s, false))}
                </div>
              </>
            )}

            {closedStrategies.length > 0 && (
              <details style={{ marginTop: 8 }}>
                <summary style={styles.sectionHeader}>
                  <span style={styles.sectionIcon}>🔒</span>
                  <span>Closed ({closedStrategies.length})</span>
                </summary>
                <div style={styles.strategyStack}>
                  {closedStrategies.map((s) => renderCard(s, false))}
                </div>
              </details>
            )}
          </>
        );
      })()}

      {/* ── Learning Modal ── */}
      {learningModal ? (
        <div style={styles.learningModalOverlay} onClick={() => setLearningModal(null)}>
          <div style={styles.learningModalBox} onClick={(e) => e.stopPropagation()}>
            <div style={styles.learningModalHeader}>
              <span style={styles.learningModalIcon}>📓</span>
              <span style={styles.learningModalTitle}>Before you close…</span>
            </div>
            <p style={styles.learningModalHint}>
              What did you learn from this trade? Any mistake you don&apos;t want to repeat?
              <span style={styles.learningModalOptional}>&nbsp;(optional — press Skip to close without noting)</span>
            </p>
            <textarea
              autoFocus
              rows={4}
              placeholder="e.g. Exited too early due to panic. Should have held till expiry…"
              value={learningText}
              onChange={(e) => setLearningText(e.target.value)}
              style={styles.learningTextarea}
            />
            <div style={styles.learningModalBtns}>
              <button
                style={styles.learningModalClose}
                onClick={() => submitLearningModal(learningText.trim() || null)}
              >🔒 Close Strategy</button>
              <button
                style={styles.learningModalSkip}
                onClick={() => submitLearningModal(null)}
              >Skip</button>
              <button style={styles.learningModalCancel} onClick={() => setLearningModal(null)}>Cancel</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

const darkStyles = {
  container: {
    minHeight: '100vh',
    background: 'linear-gradient(180deg, #020617, #0f172a)',
    color: '#e2e8f0',
    padding: '24px',
    fontFamily: "'Inter', system-ui, -apple-system, sans-serif",
  },
  loading: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#020617',
    color: '#e2e8f0',
    fontFamily: "'Inter', system-ui, sans-serif",
  },
  tickerStrip: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '8px',
    marginBottom: '18px',
  },
  tickerPill: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '8px',
    background: '#0f172a',
    border: '1px solid #1e293b',
    borderRadius: '12px',
    padding: '8px 10px',
    whiteSpace: 'nowrap',
    flex: '1 1 196px',
    minWidth: '196px',
  },
  tickerBody: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1px',
    minWidth: 0,
    flex: 1,
  },
  tickerTopRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '8px',
  },
  tickerName: {
    fontSize: '10px',
    color: '#94a3b8',
    fontWeight: '700',
    letterSpacing: '0.3px',
  },
  tickerWindow: {
    fontSize: '9px',
    fontWeight: '800',
    letterSpacing: '0.02em',
    textTransform: 'none',
  },
  tickerWindowSubtle: {
    fontSize: '8px',
    fontWeight: '700',
    color: '#94a3b8',
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
  },
  tickerBottomRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '10px',
  },
  tickerTrendRow: {
    marginTop: '3px',
    width: '100%',
    display: 'flex',
    justifyContent: 'stretch',
  },
  tickerPriceBlock: {
    display: 'flex',
    flexDirection: 'column',
    gap: '2px',
    minWidth: 0,
  },
  tickerPrice: {
    fontSize: '12px',
    fontWeight: '700',
    color: '#f8fafc',
  },
  tickerDelta: {
    fontSize: '10px',
    fontWeight: '700',
  },
  tickerSparkline: {
    width: '100%',
    height: '30px',
    display: 'block',
    overflow: 'visible',
  },
  tickerSparklineEmpty: {
    width: '100%',
    height: '30px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '9px',
    color: '#94a3b8',
  },
  tickerMetaLine: {
    fontSize: '10px',
    color: '#94a3b8',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  tickerWarningLine: {
    fontSize: '10px',
    color: '#f59e0b',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  riskBanner: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '12px',
    flexWrap: 'wrap',
    border: '2px solid',
    borderRadius: '14px',
    padding: '14px 18px',
    marginBottom: '12px',
  },
  riskBannerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
  },
  riskScoreCircle: {
    width: '48px',
    height: '48px',
    borderRadius: '50%',
    border: '3px solid',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '18px',
    fontWeight: '800',
    background: '#020617',
    flexShrink: 0,
  },
  riskLevelLabel: {
    fontSize: '15px',
    fontWeight: '700',
    letterSpacing: '0.5px',
  },
  riskPosType: {
    fontSize: '12px',
    color: '#94a3b8',
    marginTop: '2px',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '12px',
    flexWrap: 'wrap',
    marginBottom: '12px',
  },
  title: {
    margin: 0,
    fontSize: '24px',
  },
  subtitle: {
    color: '#94a3b8',
    fontSize: '12px',
    marginTop: '6px',
    lineHeight: '1.45',
    maxWidth: '640px',
  },
  headerActions: {
    display: 'flex',
    gap: '6px',
    flexWrap: 'wrap',
    alignItems: 'flex-start',
  },
  valuationBar: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
    gap: '12px',
    flexWrap: 'wrap',
    marginBottom: '10px',
    padding: '0',
    border: '1px solid #334155',
    borderLeft: '4px solid #0ea5e9',
    borderRadius: '12px',
    background: 'linear-gradient(135deg, rgba(15,23,42,0.98), rgba(2,6,23,0.94))',
    boxShadow: '0 10px 28px rgba(2, 6, 23, 0.35)',
  },
  refreshSummaryRow: {
    listStyle: 'none',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '10px',
    padding: '10px 12px',
  },
  refreshSummaryText: {
    marginTop: '2px',
    fontSize: '11px',
    color: '#94a3b8',
    lineHeight: '1.35',
  },
  refreshSummaryMeta: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexShrink: 0,
  },
  refreshMetaBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    minHeight: '24px',
    padding: '0 8px',
    borderRadius: '999px',
    background: 'rgba(148,163,184,0.12)',
    color: '#e2e8f0',
    fontSize: '10px',
    fontWeight: '700',
  },
  refreshSummaryCaret: {
    fontSize: '13px',
    color: '#94a3b8',
  },
  refreshPanelBody: {
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
    gap: '12px',
    flexWrap: 'wrap',
    padding: '0 12px 12px',
  },
  valuationTitle: {
    fontSize: '12px',
    fontWeight: '700',
    color: '#f8fafc',
    marginBottom: '2px',
  },
  valuationHint: {
    fontSize: '12px',
    color: '#94a3b8',
    lineHeight: '1.5',
    maxWidth: '700px',
  },
  valuationControlWrap: {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
    minWidth: '220px',
    maxWidth: '320px',
  },
  refreshControlWrap: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    minWidth: '260px',
    maxWidth: '380px',
    flex: '1 1 280px',
  },
  refreshControlRow: {
    display: 'grid',
    gridTemplateColumns: 'minmax(0, 1fr) minmax(140px, 180px)',
    gap: '8px',
    alignItems: 'center',
  },
  refreshToggleLabel: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    minHeight: '36px',
    color: '#e2e8f0',
    fontSize: '12px',
    fontWeight: '600',
  },
  refreshStatusText: {
    fontSize: '11px',
    color: '#cbd5e1',
    lineHeight: '1.4',
  },
  refreshMetaText: {
    fontSize: '10px',
    color: '#94a3b8',
  },
  valuationLabel: {
    fontSize: '12px',
    fontWeight: '700',
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
    color: '#e2e8f0',
  },
  valuationSelect: {
    minHeight: '38px',
    borderRadius: '10px',
    border: '1px solid var(--input-border, #475569)',
    background: 'var(--input-bg, #020617)',
    color: 'var(--input-text, #f8fafc)',
    padding: '8px 10px',
    fontSize: '12px',
    fontWeight: '600',
    outline: 'none',
  },
  primaryButton: {
    background: 'var(--btn-primary-bg, #172554)',
    border: '1px solid var(--btn-primary-border, #334155)',
    color: 'var(--btn-primary-text, #f8fafc)',
    borderRadius: '8px',
    padding: '8px 12px',
    cursor: 'pointer',
    fontWeight: '600',
    minHeight: '34px',
    fontSize: '12px',
  },
  secondaryButton: {
    background: 'var(--btn-secondary-bg, #172033)',
    border: '1px solid var(--btn-secondary-border, #334155)',
    color: 'var(--btn-secondary-text, #e2e8f0)',
    borderRadius: '8px',
    padding: '8px 12px',
    cursor: 'pointer',
    minHeight: '34px',
    fontSize: '12px',
  },
  ghostButton: {
    background: 'transparent',
    border: '1px solid var(--btn-secondary-border, rgba(148,163,184,0.18))',
    color: 'var(--btn-secondary-text, #cbd5e1)',
    borderRadius: '8px',
    padding: '8px 10px',
    cursor: 'pointer',
    minHeight: '34px',
    fontSize: '12px',
  },
  builderSection: {
    marginBottom: '14px',
    border: '1px solid #1e293b',
    borderRadius: '16px',
    background: 'rgba(15, 23, 42, 0.5)',
    overflow: 'hidden',
  },
  builderSectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '12px',
    flexWrap: 'wrap',
    padding: '14px 16px',
    borderBottom: '1px solid #1e293b',
    background: 'linear-gradient(135deg, rgba(15,23,42,0.96), rgba(15,23,42,0.72))',
  },
  builderSectionTitle: {
    color: '#f8fafc',
    fontSize: '15px',
    fontWeight: '800',
  },
  builderSectionHint: {
    marginTop: '4px',
    color: '#94a3b8',
    fontSize: '12px',
    lineHeight: '1.45',
    maxWidth: '620px',
  },
  builderSectionActions: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexWrap: 'wrap',
  },
  builderSectionBody: {
    padding: '16px',
    background: 'rgba(2, 6, 23, 0.42)',
  },
  deleteButton: {
    background: '#450a0a',
    border: '1px solid #7f1d1d',
    color: '#fecaca',
    borderRadius: '8px',
    padding: '10px 14px',
    cursor: 'pointer',
    minHeight: '44px',
    fontSize: '13px',
  },
  summaryGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
    gap: '8px',
    marginBottom: '8px',
  },
  summaryGridSecondary: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
    gap: '8px',
    marginTop: '8px',
  },
  summaryDetails: {
    marginBottom: '14px',
  },
  summaryDetailsSummary: {
    cursor: 'pointer',
    listStyle: 'none',
    display: 'inline-flex',
    alignItems: 'center',
    minHeight: '32px',
    padding: '6px 10px',
    borderRadius: '999px',
    border: '1px solid #334155',
    background: 'rgba(15, 23, 42, 0.72)',
    color: '#cbd5e1',
    fontSize: '11px',
    fontWeight: '700',
  },
  performancePanel: {
    border: '1px solid #1e293b',
    borderRadius: '14px',
    marginBottom: '16px',
    padding: '14px',
  },
  performanceHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '12px',
    flexWrap: 'wrap',
    marginBottom: '12px',
  },
  performanceTitle: {
    fontSize: '15px',
    fontWeight: '700',
  },
  performanceSubtitle: {
    fontSize: '12px',
    marginTop: '4px',
  },
  performanceDatePill: {
    border: '1px solid #334155',
    borderRadius: '999px',
    padding: '6px 10px',
    fontSize: '12px',
    fontWeight: '600',
  },
  performanceKpiGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
    gap: '10px',
    marginBottom: '12px',
  },
  performanceKpiCard: {
    border: '1px solid #1e293b',
    borderRadius: '10px',
    padding: '10px 12px',
    background: 'rgba(15, 23, 42, 0.35)',
  },
  performanceKpiLabel: {
    fontSize: '11px',
    fontWeight: '600',
    marginBottom: '6px',
  },
  performanceKpiValue: {
    fontSize: '18px',
    fontWeight: '700',
  },
  performanceChartWrap: {
    height: '260px',
    width: '100%',
  },
  summaryCard: {
    background: 'linear-gradient(135deg, #0f172a, #1e293b40)',
    border: '1px solid #1e293b',
    borderRadius: '12px',
    padding: '10px 11px',
    borderTop: '3px solid #334155',
  },
  summaryLabel: {
    color: '#94a3b8',
    fontSize: '10px',
    marginBottom: '5px',
  },
  summaryValue: {
    color: '#f8fafc',
    fontSize: '18px',
    fontWeight: 'bold',
  },
  emptyState: {
    background: 'rgba(15, 23, 42, 0.88)',
    border: '1px dashed #334155',
    borderRadius: '14px',
    padding: '16px',
    color: '#94a3b8',
    marginBottom: '16px',
  },
  errorText: {
    color: '#fca5a5',
    marginBottom: '16px',
  },
  strategyStack: {
    display: 'grid',
    gap: '14px',
  },
  strategyPanel: {
    background: 'rgba(15, 23, 42, 0.88)',
    border: '1px solid #1e293b',
    borderRadius: '14px',
    overflow: 'hidden',
  },
  strategySummary: {
    listStyle: 'none',
    cursor: 'pointer',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '12px',
    padding: '16px',
    borderLeft: '4px solid transparent',
    transition: 'border-color 0.2s',
  },
  strategyTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#f8fafc',
  },
  strategyMeta: {
    fontSize: '12px',
    color: '#94a3b8',
    marginTop: '4px',
  },
  summaryBadges: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap',
  },
  badge: {
    display: 'inline-flex',
    alignItems: 'center',
    padding: '6px 10px',
    borderRadius: '999px',
    border: '1px solid #334155',
    background: '#0f172a',
    fontSize: '12px',
    fontWeight: 'bold',
  },
  strategyBody: {
    padding: '0 16px 16px',
  },
  metricsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
    gap: '10px',
    marginBottom: '12px',
  },
  metricBox: {
    background: '#0f172a',
    border: '1px solid #1e293b',
    borderRadius: '12px',
    padding: '12px',
  },
  metricLabel: {
    color: '#94a3b8',
    fontSize: '11px',
    textTransform: 'uppercase',
    marginBottom: '6px',
  },
  metricValue: {
    color: '#f8fafc',
    fontSize: '16px',
    fontWeight: 'bold',
  },
  metricSub: {
    color: '#94a3b8',
    fontSize: '10px',
    marginTop: '4px',
  },
  infoBand: {
    display: 'grid',
    gap: '6px',
    background: '#08111f',
    border: '1px solid #1e293b',
    borderRadius: '12px',
    padding: '12px',
    color: '#cbd5e1',
    fontSize: '12px',
    marginBottom: '12px',
  },
  innerExpand: {
    background: '#08111f',
    border: '1px solid #1e293b',
    borderRadius: '12px',
    padding: '12px',
    marginBottom: '12px',
  },
  expandTitle: {
    cursor: 'pointer',
    fontWeight: 'bold',
    color: '#bfdbfe',
    marginBottom: '10px',
  },
  graphGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
    gap: '12px',
    marginTop: '12px',
  },
  graphCard: {
    background: '#0f172a',
    border: '1px solid #1e293b',
    borderRadius: '12px',
    padding: '12px',
  },
  graphTitle: {
    color: '#f8fafc',
    fontSize: '13px',
    fontWeight: 'bold',
    marginBottom: '8px',
  },
  graphHint: {
    color: '#94a3b8',
    fontSize: '11px',
    marginTop: '6px',
    lineHeight: '1.5',
  },
  closedHero: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '14px',
    flexWrap: 'wrap',
    border: '1px solid',
    borderRadius: '14px',
    padding: '16px',
    marginBottom: '14px',
  },
  closedHeroLabel: {
    color: '#94a3b8',
    fontSize: '12px',
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    marginBottom: '6px',
  },
  closedHeroValue: {
    color: '#f8fafc',
    fontSize: '28px',
    fontWeight: '800',
  },
  closedHeroStats: {
    display: 'grid',
    gap: '6px',
    color: '#e2e8f0',
    fontSize: '13px',
  },
  closedHeroKey: {
    color: '#94a3b8',
  },
  closedBars: {
    display: 'grid',
    gap: '10px',
    marginTop: '10px',
  },
  closedBarRow: {
    display: 'grid',
    gridTemplateColumns: '96px 1fr 110px',
    gap: '8px',
    alignItems: 'center',
  },
  closedBarLabelWrap: {
    minWidth: 0,
  },
  closedBarLabel: {
    color: '#f8fafc',
    fontSize: '12px',
    fontWeight: '700',
  },
  closedBarSub: {
    color: '#94a3b8',
    fontSize: '10px',
    marginTop: '2px',
  },
  closedBarTrack: {
    height: '10px',
    borderRadius: '999px',
    background: '#020617',
    overflow: 'hidden',
    border: '1px solid #1e293b',
  },
  closedBarFill: {
    height: '100%',
    borderRadius: '999px',
  },
  closedBarValue: {
    textAlign: 'right',
    fontSize: '11px',
    fontWeight: '700',
  },
  whatIfGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
    gap: '8px',
    marginTop: '12px',
  },
  whatIfCard: {
    background: '#08111f',
    border: '1px solid #1e293b',
    borderRadius: '10px',
    padding: '10px',
  },
  whatIfTopRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '8px',
    marginBottom: '8px',
  },
  whatIfSpot: {
    color: '#f8fafc',
    fontSize: '12px',
    fontWeight: '700',
  },
  whatIfOffset: {
    fontSize: '11px',
    fontWeight: '700',
    fontFamily: 'monospace',
  },
  whatIfLabel: {
    color: '#94a3b8',
    fontSize: '10px',
    textTransform: 'uppercase',
    letterSpacing: '0.04em',
    marginBottom: '4px',
  },
  whatIfValue: {
    color: '#f8fafc',
    fontSize: '16px',
    fontWeight: '700',
  },
  whatIfSubLabel: {
    color: '#94a3b8',
    fontSize: '11px',
    marginTop: '4px',
  },
  emptyChart: {
    color: '#94a3b8',
    fontSize: '12px',
    padding: '30px 0',
    textAlign: 'center',
  },
  premiumList: {
    display: 'grid',
    gap: '8px',
    marginTop: '10px',
  },
  premiumRow: {
    display: 'grid',
    gridTemplateColumns: '80px 1fr 100px',
    gap: '8px',
    alignItems: 'center',
  },
  premiumLabel: {
    color: '#cbd5e1',
    fontSize: '11px',
  },
  premiumTrack: {
    height: '10px',
    borderRadius: '999px',
    background: '#020617',
    overflow: 'hidden',
    border: '1px solid #1e293b',
  },
  premiumFill: {
    height: '100%',
    borderRadius: '999px',
  },
  premiumValue: {
    textAlign: 'right',
    fontSize: '11px',
    fontWeight: 'bold',
  },
  rangeWrap: {
    position: 'relative',
    height: '56px',
    marginTop: '8px',
  },
  rangeTrack: {
    position: 'absolute',
    top: '22px',
    left: 0,
    right: 0,
    height: '12px',
    borderRadius: '999px',
    background: '#1e293b',
  },
  rangeSeg: {
    position: 'absolute',
    top: '22px',
    height: '12px',
    borderRadius: '999px',
  },
  rangeMarker: {
    position: 'absolute',
    top: '10px',
    width: '2px',
    height: '34px',
    background: '#38bdf8',
  },
  rangeAxis: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '8px',
    color: '#94a3b8',
    fontSize: '11px',
    marginTop: '6px',
  },
  legsPanel: {
    background: '#08111f',
    border: '1px solid #1e293b',
    borderRadius: '12px',
    padding: '12px',
    marginBottom: '12px',
  },
  legsToolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '10px',
    flexWrap: 'wrap',
    marginBottom: '10px',
  },
  legsToolbarText: {
    color: '#94a3b8',
    fontSize: '11px',
  },
  legsWrap: {
    display: 'grid',
    gap: '8px',
  },
  legChip: {
    background: '#0f172a',
    border: '1px solid #334155',
    color: '#cbd5e1',
    borderRadius: '999px',
    padding: '6px 10px',
    fontSize: '11px',
  },
  cardActions: {
    display: 'flex',
    gap: '10px',
    flexWrap: 'wrap',
  },
  pastDateControls: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexWrap: 'wrap',
    padding: '8px 10px',
    borderRadius: '8px',
    border: '1px dashed #334155',
    background: 'rgba(15, 23, 42, 0.35)',
  },
  pastDateToggleLabel: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '6px',
    color: '#cbd5e1',
    fontSize: '12px',
    cursor: 'pointer',
    userSelect: 'none',
  },
  pastDateInput: {
    minHeight: '38px',
    borderRadius: '6px',
    border: '1px solid #334155',
    background: '#020617',
    color: '#e2e8f0',
    padding: '6px 8px',
    fontSize: '12px',
  },
  sectionHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    fontSize: '18px',
    fontWeight: '700',
    color: '#f8fafc',
    margin: '20px 0 10px',
    cursor: 'pointer',
    listStyle: 'none',
    background: 'linear-gradient(90deg, #1e293b40, transparent)',
    padding: '10px 14px',
    borderRadius: '10px',
  },
  sectionIcon: {
    fontSize: '20px',
  },
  statusBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    marginLeft: '10px',
    padding: '3px 8px',
    borderRadius: '999px',
    border: '1px solid',
    fontSize: '10px',
    fontWeight: 'bold',
    verticalAlign: 'middle',
  },
  buyButton: {
    background: '#14532d',
    border: '1px solid #22c55e',
    color: '#bbf7d0',
    borderRadius: '8px',
    padding: '10px 14px',
    cursor: 'pointer',
    fontWeight: 'bold',
    minHeight: '44px',
    fontSize: '13px',
  },
  closeStratBtn: {
    background: '#1e293b',
    border: '1px solid #64748b',
    color: '#e2e8f0',
    borderRadius: '8px',
    padding: '10px 14px',
    cursor: 'pointer',
    fontWeight: 'bold',
    minHeight: '44px',
    fontSize: '13px',
  },
  legChipWrap: {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
  },
  closeLegBtn: {
    background: 'none',
    border: 'none',
    color: '#f87171',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    marginLeft: '6px',
    padding: '4px 8px',
    minWidth: '32px',
    minHeight: '32px',
  },
  closeLegForm: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    flexWrap: 'wrap',
    background: '#0f172a',
    border: '1px solid #334155',
    borderRadius: '8px',
    padding: '6px 8px',
  },
  closeLegLabel: {
    color: '#94a3b8',
    fontSize: '11px',
  },
  closeLegInput: {
    width: '80px',
    background: '#020617',
    border: '1px solid #334155',
    borderRadius: '6px',
    color: '#e2e8f0',
    WebkitTextFillColor: '#e2e8f0',
    caretColor: '#e2e8f0',
    fontWeight: '700',
    padding: '8px 10px',
    fontSize: '14px',
    minHeight: '40px',
  },
  closeLegConfirm: {
    background: '#14532d',
    border: '1px solid #22c55e',
    color: '#bbf7d0',
    borderRadius: '6px',
    padding: '8px 12px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 'bold',
    minHeight: '40px',
  },
  closeLegCancel: {
    background: 'none',
    border: '1px solid #475569',
    color: '#94a3b8',
    borderRadius: '6px',
    padding: '8px 12px',
    cursor: 'pointer',
    fontSize: '12px',
    minHeight: '40px',
  },
  analyzerWrap: {
    background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.95), rgba(30, 41, 59, 0.7))',
    border: '1px solid #334155',
    borderRadius: '14px',
    padding: '16px',
    marginBottom: '14px',
  },
  analyzerHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '12px',
    flexWrap: 'wrap',
    marginBottom: '8px',
  },
  analyzerTitle: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#f8fafc',
  },
  analyzerRec: {
    display: 'inline-flex',
    alignItems: 'center',
    padding: '6px 12px',
    borderRadius: '999px',
    border: '1px solid',
    fontSize: '12px',
    fontWeight: 'bold',
    background: 'rgba(0,0,0,0.3)',
  },
  analyzerReason: {
    color: '#94a3b8',
    fontSize: '13px',
    lineHeight: '1.5',
    marginBottom: '12px',
  },
  analyzerGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
    gap: '10px',
    marginBottom: '12px',
  },
  analyzerCard: {
    background: 'linear-gradient(135deg, #0f172a, #1e293b30)',
    border: '1px solid #1e293b',
    borderRadius: '10px',
    padding: '12px',
  },
  analyzerLabel: {
    color: '#94a3b8',
    fontSize: '10px',
    textTransform: 'uppercase',
    marginBottom: '4px',
    letterSpacing: '0.5px',
  },
  analyzerValue: {
    color: '#f8fafc',
    fontSize: '15px',
    fontWeight: 'bold',
  },
  analyzerSub: {
    color: '#94a3b8',
    fontSize: '10px',
    marginTop: '4px',
  },
  gaugeWrap: {
    height: '8px',
    borderRadius: '999px',
    background: '#1e293b',
    marginTop: '6px',
    overflow: 'hidden',
  },
  gaugeBar: {
    height: '100%',
    borderRadius: '999px',
    transition: 'width 0.3s ease',
  },
  analyzerSection: {
    marginTop: '10px',
    paddingTop: '10px',
    borderTop: '1px solid #1e293b',
  },
  analyzerSubTitle: {
    fontSize: '13px',
    fontWeight: 'bold',
    color: '#cbd5e1',
    marginBottom: '8px',
  },
  legBreakdownTable: {
    display: 'grid',
    gap: '6px',
  },
  legBreakdownRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '12px',
    padding: '6px 8px',
    background: '#0f172a',
    borderRadius: '8px',
    fontSize: '12px',
    flexWrap: 'wrap',
  },
  legBreakdownLabel: {
    color: '#e2e8f0',
    fontWeight: 'bold',
    minWidth: '120px',
  },
  legBreakdownPrices: {
    color: '#94a3b8',
    flex: 1,
    textAlign: 'center',
  },
  legBreakdownPL: {
    fontWeight: 'bold',
    minWidth: '100px',
    textAlign: 'right',
  },
  suggestionList: {
    margin: '0',
    paddingLeft: '18px',
    color: '#94a3b8',
    fontSize: '12px',
    lineHeight: '1.8',
  },
  suggestionItem: {
    color: '#cbd5e1',
  },
  txDetails: {
    marginTop: '10px',
    borderTop: '1px solid #1e293b',
    paddingTop: '10px',
  },
  txSummary: {
    cursor: 'pointer',
    fontSize: '13px',
    fontWeight: 'bold',
    color: '#cbd5e1',
    listStyle: 'none',
  },
  txList: {
    display: 'grid',
    gap: '4px',
    marginTop: '8px',
  },
  txRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    padding: '6px 8px',
    background: '#0f172a',
    borderRadius: '8px',
    fontSize: '11px',
    flexWrap: 'wrap',
  },
  txType: {
    color: '#60a5fa',
    fontWeight: 'bold',
    minWidth: '50px',
  },
  txDesc: {
    color: '#cbd5e1',
    flex: 1,
  },
  txAmount: {
    fontWeight: 'bold',
    minWidth: '90px',
    textAlign: 'right',
  },
  txTime: {
    color: '#64748b',
    fontSize: '10px',
  },
  profitBanner: {
    border: '2px solid',
    borderRadius: '14px',
    padding: '16px',
    marginBottom: '14px',
  },
  profitBannerRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '16px',
    flexWrap: 'wrap',
  },
  profitBannerLabel: {
    fontSize: '12px',
    color: '#94a3b8',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    marginBottom: '4px',
  },
  profitBannerValue: {
    fontSize: '28px',
    fontWeight: 'bold',
    letterSpacing: '-0.5px',
  },
  profitBannerSplit: {
    display: 'flex',
    gap: '16px',
    fontSize: '13px',
    color: '#94a3b8',
    flexWrap: 'wrap',
  },
  profitBannerSmLabel: {
    color: '#64748b',
  },
  legCardWrap: {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
    width: '100%',
  },
  legCard: {
    background: '#0f172a',
    border: '1px solid #1e293b',
    borderRadius: '10px',
    padding: '10px 12px',
  },
  legCardHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '10px',
  },
  legRowMain: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    flexWrap: 'wrap',
    minWidth: 0,
    flex: 1,
  },
  legRowActions: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
  },
  legSideBadge: {
    padding: '2px 8px',
    borderRadius: '6px',
    fontSize: '11px',
    fontWeight: 'bold',
  },
  legCardStrike: {
    color: '#e2e8f0',
    fontWeight: 'bold',
    fontSize: '14px',
  },
  legExpiryBadge: {
    border: '1px solid',
    borderRadius: '999px',
    padding: '3px 8px',
    fontSize: '11px',
    fontWeight: '700',
    lineHeight: 1.2,
    flexShrink: 0,
  },
  legCardPL: {
    fontWeight: 'bold',
    fontSize: '14px',
  },
  legCardPrices: {
    display: 'flex',
    gap: '8px',
    fontSize: '12px',
    color: '#94a3b8',
    alignItems: 'center',
  },
  legSmallActionBtn: {
    background: '#0b1220',
    border: '1px solid #334155',
    color: '#cbd5e1',
    borderRadius: '8px',
    padding: '6px 10px',
    cursor: 'pointer',
    fontSize: '12px',
    minHeight: '34px',
  },
  closeLegInlineBtn: {
    background: '#172033',
    border: '1px solid #475569',
    color: '#e2e8f0',
    borderRadius: '8px',
    padding: '6px 10px',
    cursor: 'pointer',
    fontSize: '12px',
    minHeight: '34px',
    fontWeight: '700',
  },
  closeLegActionBtn: {
    width: '100%',
    marginTop: '8px',
    background: '#1e293b',
    border: '1px solid #475569',
    color: '#e2e8f0',
    borderRadius: '8px',
    padding: '8px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 'bold',
    minHeight: '40px',
  },
  closeLegFormHeader: {
    fontSize: '13px',
    fontWeight: 'bold',
    color: '#e2e8f0',
    marginBottom: '8px',
  },
  closeLegFormRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    flexWrap: 'wrap',
  },
  closeLegPreview: {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '6px 0',
  },
  closeLegFormBtns: {
    display: 'flex',
    gap: '8px',
    marginTop: '6px',
  },
  addLegBtn: {
    marginTop: '10px',
    width: '100%',
    background: '#0f172a',
    border: '2px dashed #334155',
    color: '#60a5fa',
    borderRadius: '10px',
    padding: '10px',
    cursor: 'pointer',
    fontSize: '13px',
    fontWeight: 'bold',
    minHeight: '44px',
  },
  addLegInlineBtn: {
    background: '#0f172a',
    border: '1px solid #334155',
    color: '#93c5fd',
    borderRadius: '9px',
    padding: '8px 12px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: '700',
    minHeight: '38px',
  },
  addLegForm: {
    marginTop: '10px',
    background: '#0f172a',
    border: '1px solid #334155',
    borderRadius: '12px',
    padding: '14px',
  },
  legEditor: {
    marginBottom: '10px',
    background: '#0f172a',
    border: '1px solid #334155',
    borderRadius: '12px',
    padding: '12px',
  },
  legEditorHeaderRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '12px',
    flexWrap: 'wrap',
    marginBottom: '10px',
  },
  legEditorTitle: {
    fontSize: '14px',
    fontWeight: '700',
    color: '#f8fafc',
  },
  legEditorHint: {
    color: '#94a3b8',
    fontSize: '11px',
    marginTop: '3px',
  },
  legEditorSpot: {
    color: '#93c5fd',
    fontSize: '12px',
    fontWeight: '700',
  },
  legEditorRow: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap',
    alignItems: 'center',
    marginBottom: '8px',
  },
  legEditorMeta: {
    display: 'flex',
    gap: '14px',
    flexWrap: 'wrap',
    color: '#94a3b8',
    fontSize: '11px',
    marginBottom: '10px',
  },
  addLegTitle: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#e2e8f0',
    marginBottom: '10px',
  },
  addLegRow: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap',
    alignItems: 'center',
    marginBottom: '10px',
  },
  addLegSelect: {
    background: '#020617',
    border: '1px solid #334155',
    borderRadius: '8px',
    color: '#e2e8f0',
    padding: '8px 10px',
    fontSize: '13px',
    minHeight: '40px',
    cursor: 'pointer',
  },
  addLegInput: {
    background: '#020617',
    border: '1px solid #334155',
    borderRadius: '8px',
    color: '#e2e8f0',
    padding: '8px 10px',
    fontSize: '13px',
    width: '90px',
    minHeight: '40px',
  },
  addLegActions: {
    display: 'flex',
    gap: '8px',
  },
  learningsTicker: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    background: 'linear-gradient(90deg, #0f172a, #1e293b40)',
    border: '1px solid #1e293b',
    borderRadius: '10px',
    padding: '8px 14px',
    marginBottom: '14px',
    overflow: 'hidden',
    minHeight: '38px',
  },
  learningsTickerLabel: {
    flexShrink: 0,
    fontSize: '11px',
    fontWeight: '700',
    color: '#fbbf24',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    paddingRight: '10px',
    borderRight: '1px solid #334155',
  },
  learningsTickerTrack: {
    flex: 1,
    overflow: 'hidden',
    position: 'relative',
  },
  learningsScrollInner: {
    display: 'inline-flex',
    alignItems: 'center',
    whiteSpace: 'nowrap',
    willChange: 'transform',
  },
  learningsTickerItem: {
    fontSize: '12px',
    color: '#cbd5e1',
    marginRight: '24px',
  },
  learningsTickerName: {
    color: '#fbbf24',
    fontWeight: '700',
  },
  learningsTickerSep: {
    color: '#334155',
    marginLeft: '24px',
  },
  learningModalOverlay: {
    position: 'fixed',
    inset: 0,
    background: 'rgba(2,6,23,0.82)',
    zIndex: 1000,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '16px',
  },
  learningModalBox: {
    background: 'linear-gradient(135deg, #0f172a, #1e293b)',
    border: '1px solid #334155',
    borderRadius: '16px',
    padding: '28px 24px',
    width: '100%',
    maxWidth: '480px',
    boxShadow: '0 24px 60px rgba(0,0,0,0.7)',
  },
  learningModalHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    marginBottom: '10px',
  },
  learningModalIcon: {
    fontSize: '24px',
  },
  learningModalTitle: {
    fontSize: '18px',
    fontWeight: '700',
    color: '#f8fafc',
  },
  learningModalHint: {
    fontSize: '13px',
    color: '#94a3b8',
    marginBottom: '14px',
    lineHeight: '1.6',
  },
  learningModalOptional: {
    color: '#64748b',
    fontSize: '12px',
  },
  learningTextarea: {
    width: '100%',
    background: '#020617',
    border: '1px solid #334155',
    borderRadius: '10px',
    color: '#e2e8f0',
    padding: '12px',
    fontSize: '13px',
    lineHeight: '1.6',
    resize: 'vertical',
    outline: 'none',
    boxSizing: 'border-box',
    marginBottom: '16px',
  },
  learningModalBtns: {
    display: 'flex',
    gap: '10px',
    flexWrap: 'wrap',
  },
  learningModalClose: {
    background: '#1e3a2a',
    border: '1px solid #22c55e',
    color: '#bbf7d0',
    borderRadius: '8px',
    padding: '10px 18px',
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: '13px',
    minHeight: '44px',
  },
  learningModalSkip: {
    background: '#1e293b',
    border: '1px solid #475569',
    color: '#94a3b8',
    borderRadius: '8px',
    padding: '10px 18px',
    cursor: 'pointer',
    fontSize: '13px',
    minHeight: '44px',
  },
  learningModalCancel: {
    background: 'none',
    border: '1px solid #334155',
    color: '#64748b',
    borderRadius: '8px',
    padding: '10px 14px',
    cursor: 'pointer',
    fontSize: '13px',
    minHeight: '44px',
  },
};
